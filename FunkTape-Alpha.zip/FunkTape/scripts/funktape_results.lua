-- FUNK // TAPE : MODULAR RESULTS / PROCEDURAL UI
-- Psych Engine 1.0.4. Install alongside funktape.lua in mods/scripts/.
-- Only judgement labels (SICK/GOOD/BAD/SHIT) load native rating images.
-- The background, panels, stars, numbers and controls remain texture-free.
-- No custom image packs, runtime texture generation, shaders or particles.
-- Owns only presentation and input; the main script owns score, save and song end.

-- Exactly three presentation roles; bundled Comfortaa-Bold.ttf remains exclusive to
-- funktape_progression.lua (LEVEL / XP / RANK / LOOP).
local FONT = {
    headline = 'NotoSansDisplay-CondensedBlack.ttf', -- brand, song, completion & controls
    award = 'NotoSerifDisplay-Bold.ttf',      -- grade, celebration & record title
    ui = 'Lato-Bold.ttf'                 -- score, stats, percentages & guidance
}
local shown = false
local canChoose = false
local issuedAction = false
local selected = 2
local effects = true
local elapsedReveal = 0
local groups = {{}, {}, {}, {}}
local groupShown = {false, false, false, false}
local nextLabel = 'CONTINUE'
local allowRetry = true
local storyMode = false
local weekFinal = false
local autoAdvanceSeconds = 0
local autoRemaining = 0
local lastAutoDisplay = ''
local accent = 'FD5B86'
local finalScore = 0
local baseline = 0
local displayedScore = nil
local scoreTime = 0
local scoreStep = 0
local earnedStars = 0
local displayedStars = -1
local starThresholds = {0.20, 0.40, 0.60, 0.80, 1.00}
local scoreDuration = 1.15
local scoreBarWidth, stageBarWidth = 665, 381
local scoreBarX, stageBarX = 86, 809

local C = {
    bg='080D18', panel='101C2C', panelAlt='142336', outline='283D55',
    white='F5F8FF', sub='A6B7CE', muted='65829D',
    shadow='070D18', teal='77DCE9', pink='FF81AC', gold='FFE18C'
}

local function num(v, def)
    local n = tonumber(v)
    if n == nil or n ~= n or n == math.huge or n == -math.huge then return def or 0 end
    return n
end

local function data(k, fallback)
    local v = getVar('ftk_r_' .. k)
    if v == nil then return fallback end
    return v
end

local function comma(n)
    n = math.floor(num(n, 0) + 0.5)
    local sign = n < 0 and '-' or ''
    local s = tostring(math.abs(n))
    return sign .. s:reverse():gsub('(%d%d%d)', '%1,'):reverse():gsub('^,', '')
end

local function limit01(v)
    return math.max(0, math.min(1, v))
end

-- STAR targets follow the main HUD's exact five thresholds, including tolerance.
-- Returns earned stars, next target, points needed and progress in the CURRENT tier.
local function starStatus(score, base)
    if base <= 0 then return 0, 0, 0, 0 end
    local count = 0
    local ratio = score / base
    for i = 1, 5 do
        if ratio + 0.00000001 >= starThresholds[i] then count = count + 1 end
    end
    if count >= 5 then return 5, 0, 0, 1 end
    local last = count == 0 and 0 or math.max(0,
        math.ceil((starThresholds[count] - 0.00000001) * base))
    local target = math.max(0, math.ceil((starThresholds[count + 1] - 0.00000001) * base))
    local need = math.max(0, math.ceil(target - score))
    return count, target, need, limit01((score - last) / math.max(1, target - last))
end

local function fill(tag, left, width, fraction)
    local amount = limit01(fraction)
    -- FlxSprite scale is center-anchored. Shift x to keep the left edge fixed.
    setProperty(tag .. '.scale.x', math.max(0.0001, amount))
    setProperty(tag .. '.x', left - width * (1 - amount) / 2)
    setProperty(tag .. '.visible', amount > 0.0001)
end

local function record(tag, group)
    if group and group > 0 then
        groups[group][#groups[group] + 1] = tag
        if effects then setProperty(tag .. '.alpha', 0) end
    end
    return tag
end

-- Backgrounds/panels: generated flat rectangles, never external image assets.
local function rect(tag, x, y, w, h, color, group)
    makeLuaSprite(tag, nil, x, y)
    makeGraphic(tag, math.max(1, math.floor(w)), math.max(1, math.floor(h)), color)
    setObjectCamera(tag, 'other')
    addLuaSprite(tag, true)
    return record(tag, group)
end

local function label(tag, value, x, y, w, size, color, align, fontRole, group)
    makeLuaText(tag, tostring(value or ''), w, x, y)
    setTextSize(tag, size)
    setTextFont(tag, FONT[fontRole or 'ui'])
    setTextColor(tag, color or C.white)
    setTextBorder(tag, 1, C.shadow)
    setTextAlignment(tag, align or 'left')
    setObjectCamera(tag, 'other')
    addLuaText(tag)
    return record(tag, group)
end

local function smallHeader(tag, text, x, y, w, group)
    label(tag, text, x, y, w, 16, C.sub, 'left',
        tag == 'ftk_result_head' and 'award' or 'ui', group)
end

-- The ONLY image-backed visual on this result screen.
-- Match Psych Engine's stage-specific rating resources rather than shipping
-- duplicate art: e.g. sick/good/bad/shit or the stage's prefixed UI versions.
local function judgementImagePath(index, fallbackName)
    local stageUI = tostring(getPropertyFromClass('states.PlayState', 'stageUI') or 'normal')
    local prefix = stageUI == 'normal' and '' or
        (tostring(getPropertyFromClass('states.PlayState', 'uiPrefix') or '') .. 'UI/')
    local suffix = tostring(getPropertyFromClass('states.PlayState', 'uiPostfix') or '')
    local sourceName = getPropertyFromGroup('ratingsData', index - 1, 'image')
    if sourceName == nil or tostring(sourceName) == '' then sourceName = fallbackName end
    return prefix .. tostring(sourceName) .. suffix
end

local function judgementIcon(tag, index, fallbackName, x, y, boxW, boxH, group, color)
    local path = judgementImagePath(index, fallbackName)
    -- Missing/misconfigured stage resources should not crash the result screen.
    local ok = pcall(makeLuaSprite, tag, path, x, y)
    local w, h = 0, 0
    if ok then
        local widthOK, width = pcall(getProperty, tag .. '.width')
        local heightOK, height = pcall(getProperty, tag .. '.height')
        w = widthOK and num(width, 0) or 0
        h = heightOK and num(height, 0) or 0
    end
    if ok and w > 0 and h > 0 then
        local scale = math.min(1.5, boxW / w, boxH / h)
        scaleObject(tag, scale, scale)
        setProperty(tag .. '.x', x + (boxW - w * scale) / 2)
        setProperty(tag .. '.y', y + (boxH - h * scale) / 2)
        setObjectCamera(tag, 'other')
        addLuaSprite(tag, true)
        return record(tag, group)
    end
    -- Text fallback is used ONLY when the game's own rating art is unavailable.
    -- The sprite was never attached to the camera if creation failed.
    return label(tag .. '_missing', fallbackName:upper(), x, y + 6, boxW,
        21, color, 'center', 'headline', group)
end

local function limit(text, max)
    text = tostring(text or '')
    if #text <= max then return text end
    return text:sub(1, max - 2) .. '..'
end

local function reveal(group)
    if groupShown[group] then return end
    groupShown[group] = true
    for _, tag in ipairs(groups[group]) do
        -- Haxe's FlxTween runs the animation; Lua does not touch alpha every frame.
        local target = 1
        if tag == 'ftk_result_retry_glow' then
            target = (selected == 1 and allowRetry) and 1 or 0.13
        elseif tag == 'ftk_result_next_glow' or tag == 'ftk_result_next_mark' then
            target = (selected ~= 1 or not allowRetry) and 1 or 0.12
        elseif tag == 'ftk_result_retry_mark' then
            target = (selected == 1 and allowRetry) and 1 or 0.12
        end
        doTweenAlpha('ftk_result_fade_' .. tag, tag, target, 0.27, 'quadOut')
    end
end

local function selection()
    if not shown then return end
    local left = selected == 1 and allowRetry
    if not effects or groupShown[4] then
        setProperty('ftk_result_retry_glow.alpha', left and 1 or 0.12)
        setProperty('ftk_result_next_glow.alpha', not left and 1 or 0.12)
        setProperty('ftk_result_retry_mark.alpha', left and 1 or 0.12)
        setProperty('ftk_result_next_mark.alpha', not left and 1 or 0.12)
    end
    -- Button labels remain light on DARK fills: no unreadable dark-on-yellow text.
    setTextColor('ftk_result_retry_label', allowRetry and C.white or C.muted)
    setTextColor('ftk_result_next_label', C.white)
end

local function updateScoreVisual(score, initial)
    local stars, _, need, within = starStatus(score, baseline)
    local ratio = baseline > 0 and score / baseline or 0
    local scoreLabel = comma(score)
    if displayedScore ~= score then
        setTextString('ftk_result_score', scoreLabel)
        displayedScore = score
    end
    fill('ftk_result_bar_fill', scoreBarX, scoreBarWidth, ratio)
    fill('ftk_result_star_progress_fill', stageBarX, stageBarWidth, within)
    if stars ~= displayedStars then
        local old = displayedStars
        displayedStars = stars
        for i = 1, 5 do
            local active = i <= stars
            setProperty('ftk_result_star_slot_' .. i .. '.color',
                getColorFromHex(active and '283E4D' or '1B2A3C'))
            for segment = 1, 5 do
                local tag = 'ftk_result_star_edge_' .. i .. '_' .. segment
                setProperty(tag .. '.color', getColorFromHex(active and accent or C.muted))
                if effects and not initial and i > math.max(0, old) and active then
                    setProperty(tag .. '.alpha', 0.28)
                    doTweenAlpha('ftk_result_star_pop_' .. i .. '_' .. segment,
                        tag, 1, 0.30, 'quadOut')
                end
            end
        end
        if effects and not initial and stars > math.max(0, old) then
            setTextString('ftk_result_star_unlock', 'STAR ' .. stars .. ' UNLOCKED!')
            setProperty('ftk_result_star_unlock.alpha', 1)
            doTweenAlpha('ftk_result_unlock_fade', 'ftk_result_star_unlock', 0, 0.64, 'quadOut')
            setProperty('ftk_result_grade_bottom.alpha', 0.25)
            doTweenAlpha('ftk_result_grade_pulse', 'ftk_result_grade_bottom', 1, 0.45, 'quadOut')
        end
    end
    local isOver = baseline > 0 and score > baseline
    local grade = isOver and 'OVERDRIVE' or
        (stars == 5 and 'ALL 5 STARS!' or (stars .. ' / 5 STARS'))
    setTextString('ftk_result_grade', grade)
    setTextColor('ftk_result_grade', isOver and C.gold or accent)
    if baseline <= 0 then
        setTextString('ftk_result_grade_info', 'NO SCORE BASELINE AVAILABLE')
    elseif stars >= 5 then
        local more = math.max(0, math.floor(score - baseline + 0.5))
        setTextString('ftk_result_grade_info', more > 0 and
            ('OVER MAX +' .. comma(more) .. ' POINTS') or 'ALL MILESTONES COMPLETED')
    else
        setTextString('ftk_result_grade_info',
            'NEXT STAR ' .. (stars + 1) .. '/5  |  NEED +' .. comma(need) .. ' POINTS')
    end
    setTextString('ftk_result_star_fraction', baseline > 0 and
        string.format('STAR PROGRESS %.1f%%', within * 100) or 'STAR PROGRESS N/A')
end

-- Five thin procedural segments form an actual five-point STAR.
-- No texture file or Unicode star glyph is required (both caused bad placeholders).
local function createResultStar(index, cx, cy, radius, group)
    local vertices = {}
    for j = 0, 4 do
        local a = -math.pi / 2 + 2 * math.pi * j / 5
        vertices[j + 1] = {cx + radius * math.cos(a), cy + radius * math.sin(a)}
    end
    for j = 1, 5 do
        local from, to = vertices[j], vertices[((j + 1) % 5) + 1]
        local dx, dy = to[1] - from[1], to[2] - from[2]
        local len = math.sqrt(dx * dx + dy * dy)
        local a = math.atan2 and math.atan2(dy, dx) or math.atan(dy / (math.abs(dx) < 0.00001 and 0.00001 or dx))
        if not math.atan2 and dx < 0 then a = a + math.pi end
        local tag = 'ftk_result_star_edge_' .. index .. '_' .. j
        rect(tag, (from[1] + to[1]) / 2 - len / 2,
            (from[2] + to[2]) / 2 - 1.5,
            math.max(1, math.floor(len + 0.5)), 3, C.muted, group)
        setProperty(tag .. '.angle', math.deg(a))
    end
end

local function updateAutoCaption(paused)
    if not storyMode or weekFinal or autoAdvanceSeconds <= 0 then return end
    local remain = math.max(0, math.ceil(autoRemaining))
    local caption = paused and
        ('AUTO NEXT PAUSED  |  RIGHT = RESUME  |  ENTER = SELECT') or
        string.format('AUTO NEXT TRACK IN %02ds  |  LEFT = PAUSE  |  ENTER = CONTINUE', remain)
    if caption ~= lastAutoDisplay then
        setTextString('ftk_result_actions', caption)
        lastAutoDisplay = caption
    end
end

local function render()
    if shown then return end
    shown = true
    canChoose = false
    issuedAction = false
    effects = data('effects', true) == true
    accent = tostring(data('accent', 'FD5B86'))
    allowRetry = data('retry', true) == true
    nextLabel = tostring(data('nextLabel', 'CONTINUE'))
    storyMode = data('story', false) == true
    weekFinal = data('last', false) == true
    autoAdvanceSeconds = (storyMode and not weekFinal) and
        math.max(0, num(data('autoSeconds', 0), 0)) or 0
    autoRemaining, lastAutoDisplay = autoAdvanceSeconds, ''
    selected = 2
    local title = limit(data('title', 'UNKNOWN - NORMAL'), 60)
    local heading = tostring(data('heading', 'SOLO RECORD'))
    local statement = tostring(data('statement', 'SONG COMPLETED!'))
    local detail = limit(data('detail', 'COMPLETED'), 83)
    local score = num(data('score', 0), 0)
    local maxScore = num(data('max', 0), 0)
    local stars = math.max(0, math.min(5, math.floor(num(data('stars', 0), 0))))
    local ratio = num(data('ratio', 0), 0)
    local pct = maxScore > 0 and string.format('%.2f%%', ratio * 100) or '???'
    local over = data('over', false) == true
    local bot = data('bot', false) == true
    local misses = num(data('misses', 0), 0)
    local combo = num(data('combo', 0), 0)
    local accuracy = bot and 'Computer' or string.format('%.2f%%', num(data('accuracy', 0), 0))
    local weekId = tostring(data('weekId', 'WEEK'))
    local weekName = tostring(data('weekName', ''))
    local trackNumber = math.max(1, math.floor(num(data('trackNumber', 1), 1)))
    local trackCount = math.max(trackNumber, math.floor(num(data('trackCount', 1), 1)))
    local weekScore = num(data('weekScore', score), score)
    local weekMax = num(data('weekMax', maxScore), maxScore)
    local weekMaxComplete = data('weekMaxComplete', true) == true
    -- Keep both Story Mode values and headings cumulative for EVERY track;
    -- Freeplay continues to show the current song's values unchanged.
    if storyMode then
        score, maxScore = weekScore, weekMax
    end
    local nextSong = tostring(data('nextSong', ''))
    local weekTitle = storyMode and ('STORY MODE  /  ' .. weekId .. '  /  ' .. weekName) or heading
    local storyLine = weekFinal and
        ('WEEK COMPLETED  //  ' .. trackCount .. ' TRACKS  //  TOTAL ' .. comma(weekScore)) or
        ('TRACK ' .. trackNumber .. ' / ' .. trackCount .. '  //  WEEK SCORE ' ..
         comma(weekScore) .. (nextSong ~= '' and ('  //  NEXT: ' .. nextSong:upper()) or ''))
    finalScore, baseline = score, maxScore
    displayedScore, displayedStars = nil, -1
    scoreTime, scoreStep = 0, 0
    for i = 1, 5 do
        starThresholds[i] = num(data('star_threshold_' .. i, 0.2 * i), 0.2 * i)
    end

    -- Static 1280 x 720 backdrop: game stage is hidden, and no artwork is loaded.
    rect('ftk_result_bg', 0, 0, 1280, 720, C.bg)
    rect('ftk_result_top_rail', 0, 0, 1280, 5, accent)
    rect('ftk_result_left_rail', 38, 35, 3, 677, accent)
    rect('ftk_result_right_rail', 1238, 35, 3, 677, C.outline)
    rect('ftk_result_frame_top', 40, 35, 1200, 2, C.outline)
    rect('ftk_result_frame_bottom', 40, 710, 1200, 2, C.outline)
    rect('ftk_result_header_rule', 66, 111, 1146, 2, C.outline)
    rect('ftk_result_header_accent', 66, 111, 200, 2, accent)
    rect('ftk_result_corner', 1198, 61, 14, 14, accent)
    rect('ftk_result_corner_dark', 1203, 61, 9, 9, C.bg)

    -- WEEK progress has its own rail, separate from the song score/STAR progress.
    -- The rail shows track 1/3, 2/3 and 3/3 without changing any engine state.
    if storyMode then
        rect('ftk_result_week_rail', 66, 218, 1146, 4, C.outline, 1)
        rect('ftk_result_week_rail_fill', 66, 218, 1146, 4, accent, 1)
        fill('ftk_result_week_rail_fill', 66, 1146, trackNumber / trackCount)
    end
    -- Score and rating cards. The same primitives work in all Story/Freeplay modes.
    rect('ftk_result_score_panel', 66, 229, 706, 209, C.panel)
    rect('ftk_result_score_panel_edge', 66, 229, 5, 209, accent)
    rect('ftk_result_grade_panel', 788, 229, 424, 209, C.panelAlt)
    rect('ftk_result_grade_panel_edge', 788, 229, 5, 209, C.teal)
    rect('ftk_result_score_split', 86, 334, 664, 2, C.outline)
    rect('ftk_result_bar_bg', 86, 410, 665, 8, C.outline)
    rect('ftk_result_bar_fill', 86, 410, 665, 8, accent, 2)

    -- Song header; leave top right empty for the progression module's LEVEL ring.
    label('ftk_result_brand', 'FUNK // TAPE', 68, 51, 430, 26, C.white, 'left', 'headline', 1)
    label('ftk_result_brand_tag', 'PERFORMANCE ARCHIVE  /  SESSION REPORT', 68, 82, 720, 15, C.sub, 'left', 'ui', 1)
    smallHeader('ftk_result_head', limit(weekTitle, 75), 68, 122, 740, 1)
    local fontSize = math.min(34, math.max(20, math.floor(706 / math.max(1, #title) / 0.43)))
    label('ftk_result_song', title, 68, 146, 720, fontSize, C.white, 'left', 'headline', 1)
    label('ftk_result_statement', limit(storyMode and storyLine or
        (statement .. '  //  ' .. detail), 95), 68, 195, 715,
        storyMode and 15 or 17, accent, 'left', storyMode and 'ui' or 'headline', 1)

    -- Score card: max remains a reference and never caps the shown score.
    smallHeader('ftk_result_score_title', storyMode and 'TOTAL SCORE' or 'FINAL SCORE', 87, 246, 350, 2)
    local scoreText = comma(score)
    local scoreSize = math.min(46, math.max(28, math.floor(656 / math.max(1, #scoreText) / 0.68)))
    label('ftk_result_score', effects and '0' or scoreText, 85, 277, 661, scoreSize, C.white, 'left', 'ui', 2)
    smallHeader('ftk_result_baseline_title', storyMode and (weekMaxComplete and 'WEEK MAX SCORE' or 'WEEK MAX SO FAR') or 'MAX SCORE', 87, 347, 350, 2)
    label('ftk_result_max', comma(maxScore), 87, 369, 360, 23, C.sub, 'left', 'ui', 2)
    label('ftk_result_accuracy', bot and 'N/A' or accuracy, 446, 362, 302, 24,
        accent, 'right', 'ui', 2)
    label('ftk_result_accuracy_caption', bot and 'BOTPLAY' or 'ACCURACY',
        451, 392, 294, 15, C.sub, 'right', 'ui', 2)

    -- Stars are real five-point shapes, not missing images or font glyphs.
    smallHeader('ftk_result_star_header', storyMode and 'WEEK STAR INDEX' or 'STAR INDEX', 810, 244, 265, 2)
    for i = 1, 5 do
        local x = 809 + (i - 1) * 76
        rect('ftk_result_star_slot_' .. i, x, 272, 65, 47, '1B2A3C', 2)
        createResultStar(i, x + 32, 296, 18, 2)
    end
    label('ftk_result_grade', '0 / 5 STARS', 809, 328, 381, 31, accent, 'center', 'award', 2)
    label('ftk_result_grade_info', 'NEXT STAR 1/5',
        808, 374, 382, 15, C.sub, 'center', 'ui', 2)
    label('ftk_result_star_fraction', 'STAR PROGRESS 0.0%',
        809, 391, 381, 13, C.sub, 'center', 'ui', 2)
    rect('ftk_result_star_progress_bg', 809, 408, 381, 6, C.outline)
    rect('ftk_result_star_progress_fill', 809, 408, 381, 6, accent, 2)
    rect('ftk_result_grade_bottom', 809, 416, 381, 3, accent, 2)
    label('ftk_result_star_unlock', '', 809, 426, 381, 14, C.gold, 'center', 'award')
    setProperty('ftk_result_star_unlock.alpha', 0)

    -- Only the four judgement titles use images. Counts and capsules stay procedural.
    smallHeader('ftk_result_breakdown', 'JUDGEMENT BREAKDOWN', 68, 445, 400, 3)
    local judgments = {
        {'sick', '78DFEC'}, {'good', '8CDDB7'},
        {'bad', 'FFD27F'}, {'shit', 'FF84A5'}
    }
    for i, item in ipairs(judgments) do
        local x = 66 + (i - 1) * 290
        local name, color = item[1], item[2]
        rect('ftk_result_hit_panel_' .. name, x, 470, 272, 107, C.panel)
        rect('ftk_result_hit_stripe_' .. name, x, 470, 272, 4, color, 3)
        judgementIcon('ftk_result_hit_icon_' .. name, i, name,
            x + 17, 483, 174, 35, 3, color)
        label('ftk_result_hit_count_' .. name, comma(data('hit_' .. name, 0)),
            x + 18, 523, 228, 30, C.white, 'left', 'ui', 3)
    end

    -- Two large selection keys. Background glow changes only when selection does.
    rect('ftk_result_retry_bg', 66, 594, 554, 55, C.panelAlt)
    rect('ftk_result_next_bg', 638, 594, 574, 55, C.panelAlt)
    rect('ftk_result_retry_glow', 69, 597, 548, 49, '2C485E', 4)
    rect('ftk_result_next_glow', 641, 597, 568, 49, '2C485E', 4)
    rect('ftk_result_retry_mark', 69, 597, 548, 3, accent, 4)
    rect('ftk_result_next_mark', 641, 597, 568, 3, accent, 4)
    label('ftk_result_retry_label', allowRetry and 'R  /  RETRY TRACK' or 'RETRY DISABLED',
        85, 606, 523, 23, C.white, 'center', 'ui', 4)
    label('ftk_result_next_label', 'ENTER  /  ' .. nextLabel,
        652, 606, 547, 23, C.white, 'center', 'ui', 4)
    label('ftk_result_actions', 'LEFT / RIGHT  =  SELECT                         ENTER  =  CONFIRM',
        71, 658, 1125, 15, C.sub, 'center', 'ui', 4)

    -- Populate static state (without animation) or initialize a zeroed tally.
    updateScoreVisual(effects and 0 or finalScore, true)

    -- Standalone progression uses this tag as its stable foreground ordering anchor.
    -- Never rename ftk_result_actions without updating funktape_progression.lua.
    if effects then
        elapsedReveal = 0
        groupShown = {false, false, false, false}
    else
        canChoose = true
    end
    setVar('ftk_result_ui_active', true)
    selection()
    updateAutoCaption(false)
end

local function updateResultAnimation(dt)
    if canChoose or not effects then return end
    elapsedReveal = elapsedReveal + math.max(0, num(dt, 0))
    if elapsedReveal >= 0.03 then reveal(1) end
    if elapsedReveal >= 0.16 then reveal(2) end
    if elapsedReveal >= 0.30 then reveal(3) end

    -- The final score is an immutable snapshot. Only its on-screen count and
    -- procedural progress bars animate; no gameplay score/save values change.
    scoreTime = math.max(0, elapsedReveal - 0.22)
    if scoreTime > 0 and scoreStep ~= 99 then
        local t = limit01(scoreTime / scoreDuration)
        local eased = 1 - (1 - t) * (1 - t) * (1 - t)
        local now = t >= 1 and finalScore or math.floor(finalScore * eased + 0.5)
        -- At most one batch of text + bar updates per 1/30s (no new objects).
        if scoreStep == 0 or t >= 1 or scoreTime - scoreStep >= (1 / 30) then
            updateScoreVisual(now, false)
            scoreStep = scoreTime
            if t >= 1 then scoreStep = 99 end
        end
    end
    if elapsedReveal >= 1.22 then reveal(4) end
    if elapsedReveal >= 1.57 then canChoose = true end
end

function onCreatePost()
    setVar('ftk_result_module_seen', true)
end

function onUpdatePost(elapsed)
    if getVar('ftk_phase') ~= 'result' or getVar('ftk_result_ready') ~= true then return end
    if not shown then
        render()
        return -- avoid handling a key on the very frame the result is created
    end
    updateResultAnimation(elapsed)
    if not canChoose or issuedAction then return end
    -- Progression's three-step LOOP flow owns L and ENTER until it is resolved.
    if num(getVar('ftk_loop_confirm'), 0) > 0
        or getVar('ftk_loop_suppress') == true or keyboardJustPressed('L') then
        updateAutoCaption(true)
        return
    end
    if allowRetry and keyboardJustPressed('R') then
        issuedAction = true
        setVar('ftk_result_action', 'retry')
        return
    end
    if allowRetry and keyJustPressed('left') then
        selected = 1
        selection()
    elseif keyJustPressed('right') then
        selected = 2
        selection()
    end
    if keyJustPressed('accept') or keyboardJustPressed('ENTER') then
        issuedAction = true
        setVar('ftk_result_action', selected == 1 and 'retry' or 'continue')
        return
    end
    -- Countdown begins only after result reveal. Selecting RETRY or opening
    -- LOOP confirmation pauses it; neither can accidentally auto-retry/advance.
    if autoAdvanceSeconds > 0 then
        if selected == 2 then
            autoRemaining = math.max(0, autoRemaining - math.max(0, num(elapsed, 0)))
            updateAutoCaption(false)
            if autoRemaining <= 0 then
                issuedAction = true
                setVar('ftk_result_action', 'continue')
            end
        else
            updateAutoCaption(true)
        end
    end
end
