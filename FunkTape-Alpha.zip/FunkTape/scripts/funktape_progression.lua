local PROG_SAVE = 'funktape_progression_v1'

local RESET_MOD_FOLDER = 'FunkTape'
local RESET_BACKUP_SAVE = 'funktape_progression_reset_backup_v1'
local RESET_LAST_ID_FIELD = 'modResetConsumedId'
local resetNotice = false
local progression = {level=1, xp=0, loop=0, total=0, earnedThisSong=0, dirty=false}
local loopConfirm = 0

local levelUp = {active=false, from=0, target=0, elapsed=0, duration=1.55}
local showLevelUp
local rankLabels = {'ROOKIE','BEGINNER','PERFORMER','EXPERT','SPECIALIST','MASTER','LEGEND'}

local XP_BY_RATING = {sick=4, good=3, bad=2, shit=1}

-- Circular LEVEL badge: fixed objects, XP-based fill, no per-frame allocation.
local RING_SEGMENTS = 20
local RING_RADIUS = 29
local ringSprites = {}
local ringCreated = false
local ringVisible = nil
local ringLastUnits = -1
local ringLastLevel = -1
local ringLastCaption = ''
local ringColorActive = nil
local ringColorInactive = nil
local ringColorActiveHex = 'A5EAFF'
local ringColorInactiveHex = '24364B'
local ringLastColorKey = ''
local ringTargetFraction = 0
local ringDisplayFraction = 0
local ringLastColorLevel = -1
local ringLastColorMax = -1
local ringLayoutIsResult = nil
local resultRingPromoted = false
local resultTextLevel = -1
local resultTextLoop = -1
local resultTextXP = -1

local LEVEL_COLOR_KEYS = {
    {ratio = 0.00, color = 'FF4D4D'},
    {ratio = 0.17, color = 'FF9933'},
    {ratio = 0.33, color = 'FFE34D'},
    {ratio = 0.50, color = '47D66B'},
    {ratio = 0.67, color = '499BFF'},
    {ratio = 0.83, color = '635BDD'},
    {ratio = 1.00, color = 'B16DFA'}
}

local function hexToRgb(hex)
    return tonumber(hex:sub(1, 2), 16), tonumber(hex:sub(3, 4), 16), tonumber(hex:sub(5, 6), 16)
end

local function rgbToHex(r, g, b)
    r = math.max(0, math.min(255, math.floor(r + 0.5)))
    g = math.max(0, math.min(255, math.floor(g + 0.5)))
    b = math.max(0, math.min(255, math.floor(b + 0.5)))
    return string.format('%02X%02X%02X', r, g, b)
end

local function lerpNumber(a, b, t)
    return a + (b - a) * t
end

local function blendHex(hexA, hexB, t)
    local ar, ag, ab = hexToRgb(hexA)
    local br, bg, bb = hexToRgb(hexB)
    return rgbToHex(lerpNumber(ar, br, t), lerpNumber(ag, bg, t), lerpNumber(ab, bb, t))
end

local function darkenHex(hex, factor)
    local r, g, b = hexToRgb(hex)
    return rgbToHex(r * factor, g * factor, b * factor)
end

local function maxProgressLevel()
    local maxlevelold = 200 * (1.1 ^ progression.loop) + 0.000001
    local maxlevel = math.ceil(maxlevelold)
    return maxlevel
end
local function neededLevelXP(level)
    local levelxpold = (100 + 20 * (level - 1)) * (1 + progression.loop * 0.1)
    local levelxp = math.ceil(levelxpold)

    return levelxp
end
local function currentRankIndex()
    local fraction = (progression.level - 1) / math.max(1, maxProgressLevel() - 1)
    return math.min(#rankLabels, math.floor(fraction * #rankLabels) + 1)
end

local function currentRank()
    return rankLabels[currentRankIndex()]
end

local function resolveLevelColorHex()
    local ratio = (progression.level - 1) / math.max(1, maxProgressLevel() - 1)
    local prev = LEVEL_COLOR_KEYS[1]
    for i = 2, #LEVEL_COLOR_KEYS do
        local nxt = LEVEL_COLOR_KEYS[i]
        if ratio <= nxt.ratio then
            local span = math.max(0.0001, nxt.ratio - prev.ratio)
            local t = math.max(0, math.min(1, (ratio - prev.ratio) / span))
            return blendHex(prev.color, nxt.color, t)
        end
        prev = nxt
    end
    return LEVEL_COLOR_KEYS[#LEVEL_COLOR_KEYS].color
end

local function refreshRingPalette(force)
    local maxLevel = maxProgressLevel()
    if not force and ringLastColorLevel == progression.level and ringLastColorMax == maxLevel then
        return false
    end
    ringLastColorLevel = progression.level
    ringLastColorMax = maxLevel
    local activeHex = resolveLevelColorHex()
    local inactiveHex = darkenHex(activeHex, 0.26)
    local key = activeHex .. '/' .. inactiveHex
    if (not force) and key == ringLastColorKey then return false end
    ringLastColorKey = key
    ringColorActiveHex = activeHex
    ringColorInactiveHex = inactiveHex
    ringColorActive = getColorFromHex(activeHex)
    ringColorInactive = getColorFromHex(inactiveHex)
    return true
end

local function getTargetRingFraction()
    if progression.level >= maxProgressLevel() then return 1 end
    return math.max(0, math.min(1, progression.xp / math.max(1, neededLevelXP(progression.level))))
end

local function applyRingVisual(force)
    if not ringCreated then return end
    local paletteChanged = refreshRingPalette(false)
    if paletteChanged then ringLastUnits = -1 end
    local units = math.floor(ringDisplayFraction * RING_SEGMENTS * 8 + 0.5)
    if force or units ~= ringLastUnits then
        ringLastUnits = units
        local full = math.floor(units / 8)
        local part = units % 8
        for i = 1, RING_SEGMENTS do
            local sprite = ringSprites[i]
            if i <= full then
                setProperty(sprite .. '.color', ringColorActive)
                setProperty(sprite .. '.alpha', 1)
            elseif i == full + 1 and part > 0 then
                setProperty(sprite .. '.color', ringColorActive)
                setProperty(sprite .. '.alpha', 0.22 + part * 0.095)
            else
                setProperty(sprite .. '.color', ringColorInactive)
                setProperty(sprite .. '.alpha', 0.48)
            end
        end
    end
    if progression.level ~= ringLastLevel then
        ringLastLevel = progression.level
        setTextString('ftk_ring_level', tostring(progression.level))
    end
    local caption = progression.level >= maxProgressLevel() and 'MAX' or 'LV'
    if paletteChanged then
        -- Apply the same level-derived color to the ring, its numeric LEVEL,
        -- and the companion LEVEL/LOOP/RANK text (including the result view).
        setTextColor('ftk_ring_level', ringColorActiveHex)
        setTextColor('ftk_ring_caption', ringColorActiveHex)
        setTextColor('ftk_level_info', ringColorActiveHex)
        setTextColor('ftk_loop_notice', ringColorActiveHex)
        setTextColor('ftk_levelup_detail', ringColorActiveHex)
    end
    if force or caption ~= ringLastCaption then
        ringLastCaption = caption
        setTextString('ftk_ring_caption', caption)
    end
end

local function stepRingAnimation(elapsed, instant)
    ringTargetFraction = getTargetRingFraction()
    if instant then
        ringDisplayFraction = ringTargetFraction
    else
        local speed = ringTargetFraction > ringDisplayFraction and 8.5 or 5.5
        local t = math.max(0, math.min(1, (tonumber(elapsed) or 0) * speed))
        ringDisplayFraction = lerpNumber(ringDisplayFraction, ringTargetFraction, t)
        if math.abs(ringDisplayFraction - ringTargetFraction) < 0.003 then
            ringDisplayFraction = ringTargetFraction
        end
    end
    applyRingVisual(instant)
end

local function loadProgression()
    initSaveData(PROG_SAVE)
    progression.loop = math.max(0, math.floor(tonumber(getDataFromSave(PROG_SAVE,'loop',0)) or 0))
    progression.loop = math.min(50, progression.loop) -- finite, safe integer growth
    progression.level = math.max(1,math.min(maxProgressLevel(),math.floor(tonumber(getDataFromSave(PROG_SAVE,'level',1)) or 1)))
    progression.xp = math.max(0,tonumber(getDataFromSave(PROG_SAVE,'xp',0)) or 0)
    progression.total = math.max(0,tonumber(getDataFromSave(PROG_SAVE,'total',0)) or 0)
    if progression.level >= maxProgressLevel() then progression.xp=0 end
end
local function persistProgression(flush)
    if not progression.dirty then return end
    setDataFromSave(PROG_SAVE,'level',progression.level)
    setDataFromSave(PROG_SAVE,'xp',progression.xp)
    setDataFromSave(PROG_SAVE,'loop',progression.loop)
    setDataFromSave(PROG_SAVE,'total',progression.total)
    if flush then flushSaveData(PROG_SAVE); progression.dirty=false end
end

local function resetConfirmIsOn(value)
    return value == true or value == 1 or value == 'true' or value == '1'
end
local function consumeSettingsReset()
    local okID, rawID = pcall(getModSetting, 'ftk_reset_request_id', RESET_MOD_FOLDER)
    local okConfirm, rawConfirm = pcall(getModSetting, 'ftk_reset_confirm', RESET_MOD_FOLDER)
    if not okID or not okConfirm then
        return false
    end
    if rawID == nil or rawConfirm == nil then
        return false
    end

    local requested = tonumber(rawID)
    if requested == nil or requested ~= requested or requested == math.huge or requested == -math.huge then
        return false
    end
    local requestID = math.floor(requested)
    local lastID = tonumber(getDataFromSave(PROG_SAVE, RESET_LAST_ID_FIELD, 0)) or 0
    local confirmed = resetConfirmIsOn(rawConfirm)
    if requestID < 1 or requestID > 999 then
        return false
    end
    if not confirmed then
        return false
    end
    if requestID <= lastID then
        return false
    end

    -- Snapshot first. Fail closed if backup cannot be created/verified.
    local okBackup, backupError = pcall(function()
        initSaveData(RESET_BACKUP_SAVE)
        setDataFromSave(RESET_BACKUP_SAVE, 'level', progression.level)
        setDataFromSave(RESET_BACKUP_SAVE, 'xp', progression.xp)
        setDataFromSave(RESET_BACKUP_SAVE, 'loop', progression.loop)
        setDataFromSave(RESET_BACKUP_SAVE, 'total', progression.total)
        setDataFromSave(RESET_BACKUP_SAVE, 'requestID', requestID)
        flushSaveData(RESET_BACKUP_SAVE)
    end)
    if not okBackup then
        return false
    end
    if tonumber(getDataFromSave(RESET_BACKUP_SAVE, 'requestID', -1)) ~= requestID
        or tonumber(getDataFromSave(RESET_BACKUP_SAVE, 'level', -1)) ~= progression.level
        or tonumber(getDataFromSave(RESET_BACKUP_SAVE, 'xp', -1)) ~= progression.xp
        or tonumber(getDataFromSave(RESET_BACKUP_SAVE, 'loop', -1)) ~= progression.loop
        or tonumber(getDataFromSave(RESET_BACKUP_SAVE, 'total', -1)) ~= progression.total then
        return false
    end

    -- One save object contains the reset values and the consumed request marker.
    -- Existing score/song/engine settings are not accessed.
    local okSave, saveError = pcall(function()
        setDataFromSave(PROG_SAVE, 'level', 1)
        setDataFromSave(PROG_SAVE, 'xp', 0)
        setDataFromSave(PROG_SAVE, 'loop', 0)
        setDataFromSave(PROG_SAVE, 'total', 0)
        setDataFromSave(PROG_SAVE, RESET_LAST_ID_FIELD, requestID)
        flushSaveData(PROG_SAVE)
    end)
    if not okSave then
        return false
    end
    progression.level = 1
    progression.xp = 0
    progression.loop = 0
    progression.total = 0
    progression.earnedThisSong = 0
    progression.dirty = false
    loopConfirm = 0
    resetNotice = true
    return true
end

local function gainExperience(amount)
    amount=tonumber(amount) or 0
    if amount <= 0 then return end
    progression.total=progression.total+amount
    progression.earnedThisSong=progression.earnedThisSong+amount
    progression.dirty=true
    local maximum=maxProgressLevel()
    if progression.level >= maximum then return end
    progression.xp=progression.xp+amount
    local previousLevel = progression.level
    while progression.level < maximum do
        local needed=neededLevelXP(progression.level)
        if progression.xp < needed then break end
        progression.xp=progression.xp-needed
        progression.level=progression.level+1
    end
    if progression.level >= maximum then progression.xp=0 end
    if progression.level > previousLevel and showLevelUp then
        showLevelUp(previousLevel, progression.level)
    end
end
local function xpForNote(base)
    -- BOTPLAY: exactly 1 XP for every valid head or sustain tick.
    -- Ignore difficulty and song-length multipliers for bot-controlled play.
    if getProperty('cpuControlled') == true then return 1 end
    local currentDifficulty = tonumber(getPropertyFromClass('states.PlayState','storyDifficulty')) or 1
    local d = currentDifficulty == 0 and 0.75 or (currentDifficulty == 1 and 1.0 or 1.2)
    local seconds = tonumber(getProperty('songLength')) or 0
    seconds=seconds/1000
    local duration= seconds > 0 and math.max(0.75, math.min(1.5, seconds / 150)) or 1
    return base*d*duration
end
local function performLoop()
    if progression.loop >= 50 or progression.level < maxProgressLevel() then return false end
    progression.loop=progression.loop+1
    progression.level=1
    progression.xp=0
    progression.dirty=true
    persistProgression(true)
    return true
end

-- Standalone global song script: install in mods/scripts/.
-- No dependency on the base HUD's private Lua locals.
local hudCreated = false
local clock = 0
local saveClock = 0
local loopHint = ''
local lastXPLayoutText = nil
local function phaseIsResult() return getVar('ftk_phase') == 'result' end
local function setRingVisible(visible)
    if not ringCreated or ringVisible == visible then return end
    ringVisible = visible
    for i = 1, #ringSprites do
        setProperty(ringSprites[i] .. '.visible', visible)
    end
    setProperty('ftk_ring_level.visible', visible)
    setProperty('ftk_ring_caption.visible', visible)
end

local function updateRingProgress(forceInstant)
    if not ringCreated then return end
    stepRingAnimation(0.12, forceInstant == true)
end

-- Promote the persistent LEVEL ring only AFTER the result script has
-- instantiated its procedural UI. Lua scripts may execute onUpdatePost in
-- either order: a one-shot promotion can silently bury the ring behind the UI.
local function promoteResultRing()
    if resultRingPromoted or not ringCreated then return end
    local ok, order = pcall(getObjectOrder, 'ftk_result_actions')
    if not ok or type(order) ~= 'number' or order < 0 then return end
    local index = order + 1
    for i = 1, RING_SEGMENTS do
        setObjectOrder(ringSprites[i], index)
        index = index + 1
    end
    setObjectOrder('ftk_ring_level', index)
    setObjectOrder('ftk_ring_caption', index + 1)
    setObjectOrder('ftk_level_info', index + 2)
    setObjectOrder('ftk_level_xp', index + 3)
    resultRingPromoted = true
end

local function applyRingLayout(resultMode)
    if not ringCreated then return end
    if ringLayoutIsResult == resultMode then
        if resultMode then promoteResultRing() end
        return
    end
    ringLayoutIsResult = resultMode
    if not resultMode then resultRingPromoted = false end
    local cx, cy, textX, textY, textAlign
    if resultMode then
        cx, cy, textX, textY, textAlign = 1146, 132, 804, 176, 'right'
    else
        local downScroll = getPropertyFromClass('backend.ClientPrefs', 'data.downScroll') == true
        local progressY = downScroll and 212 or 452
        cx, cy, textX, textY, textAlign = 55, progressY + 22, 108, progressY + 2, 'left'
    end
    for i = 1, RING_SEGMENTS do
        local degrees = -90 + (i - 1) * 360 / RING_SEGMENTS
        local radians = math.rad(degrees)
        setProperty(ringSprites[i] .. '.x', cx + math.cos(radians) * RING_RADIUS - 5.5)
        setProperty(ringSprites[i] .. '.y', cy + math.sin(radians) * RING_RADIUS - 2)
    end
    setProperty('ftk_ring_level.x', cx - 33)
    setProperty('ftk_ring_level.y', cy - 22)
    setProperty('ftk_ring_caption.x', cx - 33)
    setProperty('ftk_ring_caption.y', cy + 7)
    setProperty('ftk_level_info.x', textX)
    setProperty('ftk_level_info.y', textY)
    setProperty('ftk_level_xp.x', textX)
    setProperty('ftk_level_xp.y', textY + 31)
    setTextAlignment('ftk_level_info', textAlign)
    setTextAlignment('ftk_level_xp', textAlign)
    -- The gameplay-only backdrop must never overlap the separated result screen.
    if resultMode then promoteResultRing() end
end

local function makeProgressLabels()
    if hudCreated then return end
    -- Place progression below the active song title and away from gameplay HUD.
    -- Downscroll uses the upper-left instead of the bottom receptor area.
    local downScroll = getPropertyFromClass('backend.ClientPrefs','data.downScroll') == true
    local progressY = downScroll and 211 or 455
    -- The LEVEL itself lives inside the ring; the old duplicate LV number is removed.
    local ringX, ringY = 55, progressY + 22
    -- No gameplay panel: the stage and note highway remain unobscured.
    refreshRingPalette(true)
    ringTargetFraction = getTargetRingFraction()
    ringDisplayFraction = ringTargetFraction
    local segmentW, segmentH = 11, 4
    for i = 1, RING_SEGMENTS do
        local degrees = -90 + (i - 1) * 360 / RING_SEGMENTS
        local radians = math.rad(degrees)
        local x = ringX + math.cos(radians) * RING_RADIUS - segmentW * 0.5
        local y = ringY + math.sin(radians) * RING_RADIUS - segmentH * 0.5
        local tag = 'ftk_ring_segment_' .. i
        makeLuaSprite(tag, nil, x, y)
        makeGraphic(tag, segmentW, segmentH, '24364B')
        setObjectCamera(tag, 'other')
        setProperty(tag .. '.angle', degrees + 90)
        setProperty(tag .. '.alpha', 0.42)
        addLuaSprite(tag, true)
        ringSprites[i] = tag
    end
    makeLuaText('ftk_ring_level', '', 66, ringX - 33, progressY + 3)
    setTextAlignment('ftk_ring_level', 'center')
    setTextSize('ftk_ring_level', 28)
    setTextFont('ftk_ring_level', 'Comfortaa-Bold.ttf')
    setTextColor('ftk_ring_level', ringColorActiveHex)
    setTextBorder('ftk_ring_level', 3, '050813')
    addLuaText('ftk_ring_level')
    setObjectCamera('ftk_ring_level', 'other')
    makeLuaText('ftk_ring_caption', '', 66, ringX - 33, progressY + 28)
    setTextAlignment('ftk_ring_caption', 'center')
    setTextSize('ftk_ring_caption', 13)
    setTextFont('ftk_ring_caption', 'Comfortaa-Bold.ttf')
    setTextColor('ftk_ring_caption', ringColorActiveHex)
    setTextBorder('ftk_ring_caption', 3, '050813')
    addLuaText('ftk_ring_caption')
    setObjectCamera('ftk_ring_caption', 'other')
    ringCreated = true
    makeLuaText('ftk_level_info', '', 292, 108, progressY + 2)
    setTextAlignment('ftk_level_info', 'left')
    setTextSize('ftk_level_info', 17)
    setTextFont('ftk_level_info', 'Comfortaa-Bold.ttf')
    setTextColor('ftk_level_info', ringColorActiveHex)
    setTextBorder('ftk_level_info', 3, '050813')
    addLuaText('ftk_level_info')
    setObjectCamera('ftk_level_info', 'other')
    makeLuaText('ftk_level_xp', '', 292, 108, progressY + 31)
    setTextAlignment('ftk_level_xp', 'left')
    setTextSize('ftk_level_xp', 13)
    setTextFont('ftk_level_xp', 'Comfortaa-Bold.ttf')
    setTextColor('ftk_level_xp', 'D5E2F8')
    setTextBorder('ftk_level_xp', 3, '050813')
    addLuaText('ftk_level_xp')
    setObjectCamera('ftk_level_xp', 'other')
    makeLuaText('ftk_loop_notice','',1146,66,684)
    setTextSize('ftk_loop_notice', 17)
    setTextAlignment('ftk_loop_notice','center')
    setTextFont('ftk_loop_notice','Comfortaa-Bold.ttf')
    setTextColor('ftk_loop_notice',ringColorActiveHex)
    setTextBorder('ftk_loop_notice',1,'070B13')
    addLuaText('ftk_loop_notice')
    setObjectCamera('ftk_loop_notice','other')
    setProperty('ftk_loop_notice.visible',false)
    -- Fixed cost: two reusable text objects. Never allocate on each note/level.
    makeLuaText('ftk_levelup_title', 'LEVEL UP!', 520, 380, 242)
    setTextSize('ftk_levelup_title', 42)
    setTextAlignment('ftk_levelup_title', 'center')
    setTextFont('ftk_levelup_title', 'Comfortaa-Bold.ttf')
    setTextColor('ftk_levelup_title', 'FCE773')
    setTextBorder('ftk_levelup_title', 2, '070B13')
    addLuaText('ftk_levelup_title')
    setObjectCamera('ftk_levelup_title', 'other')
    setProperty('ftk_levelup_title.alpha', 0)
    setProperty('ftk_levelup_title.visible', false)
    makeLuaText('ftk_levelup_detail', '', 520, 380, 296)
    setTextSize('ftk_levelup_detail', 23)
    setTextAlignment('ftk_levelup_detail', 'center')
    setTextFont('ftk_levelup_detail', 'Comfortaa-Bold.ttf')
    setTextColor('ftk_levelup_detail', ringColorActiveHex)
    setTextBorder('ftk_levelup_detail', 2, '070B13')
    addLuaText('ftk_levelup_detail')
    setObjectCamera('ftk_levelup_detail', 'other')
    setProperty('ftk_levelup_detail.alpha', 0)
    setProperty('ftk_levelup_detail.visible', false)
    hudCreated=true
    applyRingLayout(false)
end

local function hideLevelUp()
    if not levelUp.active then return end
    levelUp.active=false
    cancelTween('ftk_lu_title_in')
    cancelTween('ftk_lu_detail_in')
    cancelTween('ftk_lu_title_out')
    cancelTween('ftk_lu_detail_out')
    setProperty('ftk_levelup_title.visible',false)
    setProperty('ftk_levelup_detail.visible',false)
end

-- Show only LEVEL UP! / LEVEL NUMBER + LOOP count; no progression subtitle.
-- Coalesce consecutive level ups into one notification, without creating a queue.
showLevelUp = function(fromLevel, toLevel)
    if not hudCreated or phaseIsResult() or getVar('ftk_phase') ~= 'play' then return end
    if levelUp.active then
        fromLevel = levelUp.from
    end
    levelUp.from=fromLevel
    levelUp.target=toLevel
    levelUp.elapsed=0
    levelUp.active=true
    cancelTween('ftk_lu_title_in')
    cancelTween('ftk_lu_detail_in')
    cancelTween('ftk_lu_title_out')
    cancelTween('ftk_lu_detail_out')
    setTextString('ftk_levelup_title',toLevel >= maxProgressLevel() and 'MAX LEVEL!' or 'LEVEL UP!')
    setTextString('ftk_levelup_detail',string.format('LEVEL %d  |  LOOP %d', toLevel, progression.loop))
    setTextColor('ftk_levelup_detail', resolveLevelColorHex())
    setProperty('ftk_levelup_title.visible',true)
    setProperty('ftk_levelup_detail.visible',true)
    setProperty('ftk_levelup_title.alpha',0)
    setProperty('ftk_levelup_detail.alpha',0)
    doTweenAlpha('ftk_lu_title_in','ftk_levelup_title',1,0.16,'quadOut')
    doTweenAlpha('ftk_lu_detail_in','ftk_levelup_detail',1,0.21,'quadOut')
end
local function updateProgressText(forceInstant)
    if not hudCreated then return end
    -- Existing information stays readable but LEVEL is displayed only once, in the ring.
    setTextString('ftk_level_info', string.format('LOOP %d  |  %s', progression.loop, currentRank()))
    local label = progression.level >= maxProgressLevel() and 'MAX LEVEL - LOOP AVAILABLE AT RESULTS' or
        string.format('XP %.1f / %d  (+%.1f THIS SONG)', progression.xp, neededLevelXP(progression.level), progression.earnedThisSong)
    -- Preserve the full XP information while keeping its 292px reserved width.
    -- Cache the size to avoid pointless font updates every 0.1 seconds.
    if label ~= lastXPLayoutText then
        lastXPLayoutText = label
        local fitted = math.floor(286 / math.max(1, #label) / 0.55)
        setTextSize('ftk_level_xp', math.max(9, math.min(13, fitted)))
    end
    setTextString('ftk_level_xp', label)
    if forceInstant == true then updateRingProgress(true) end
end

local function updateLoopHint()
    if not hudCreated then return end
    local caption = progression.level >= maxProgressLevel() and progression.loop < 50 and 'L = LOOP (MAX LEVEL REACHED)' or 'LOOP LOCKED - REACH MAX LEVEL'
    if progression.loop >= 50 then caption = 'LOOP LIMIT REACHED'
    elseif loopConfirm == 1 then caption = 'PERFORM LOOP? PRESS L AGAIN'
    elseif loopConfirm == 2 then caption = 'ARE YOU SURE? THIS CANNOT BE UNDONE.' end
    if caption ~= loopHint then setTextString('ftk_loop_notice',caption); loopHint=caption end
end
function onCreatePost()
    loadProgression()
    consumeSettingsReset()
    makeProgressLabels()
    setVar('ftk_loop_confirm',0)
    setVar('ftk_loop_suppress',false)
    updateProgressText(true)
    -- Reset handler above prints an explicit success / refusal reason.
end
function onUpdatePost(elapsed)
    setVar('ftk_loop_suppress',false)
    if phaseIsResult() then
        applyRingLayout(true)
        hideLevelUp()
        persistProgression(true)
        setProperty('ftk_level_info.visible',true)
        setProperty('ftk_level_xp.visible',true)
        setRingVisible(true)
        setProperty('ftk_loop_notice.visible',true)
        if keyboardJustPressed('ESCAPE') and loopConfirm > 0 then loopConfirm=0
        elseif keyboardJustPressed('L') and progression.loop < 50 and progression.level >= maxProgressLevel() then
            loopConfirm=math.min(2,loopConfirm+1)
        elseif loopConfirm == 2 and (keyboardJustPressed('ENTER') or keyJustPressed('accept')) then
            setVar('ftk_loop_suppress',true)
            performLoop()
            loopConfirm=0
        end
        setVar('ftk_loop_confirm',loopConfirm)
        stepRingAnimation(elapsed, false)
        if resultTextLevel ~= progression.level or resultTextLoop ~= progression.loop
            or resultTextXP ~= progression.xp then
            resultTextLevel = progression.level
            resultTextLoop = progression.loop
            resultTextXP = progression.xp
            updateProgressText()
        end
        updateLoopHint()
        return
    end
    if hudCreated then
        applyRingLayout(false)
        setProperty('ftk_level_info.visible',true)
        setProperty('ftk_level_xp.visible',true)
        setRingVisible(true)
        setProperty('ftk_loop_notice.visible',false)
    end
    loopConfirm=0
    setVar('ftk_loop_confirm',0)
    local dt=tonumber(elapsed) or 0
    stepRingAnimation(dt, false)
    if levelUp.active then
        levelUp.elapsed=levelUp.elapsed+dt
        if levelUp.elapsed >= levelUp.duration then
            hideLevelUp()
        elseif levelUp.elapsed >= 1.10 and levelUp.elapsed-dt < 1.10 then
            doTweenAlpha('ftk_lu_title_out','ftk_levelup_title',0,0.40,'quadIn')
            doTweenAlpha('ftk_lu_detail_out','ftk_levelup_detail',0,0.40,'quadIn')
        end
    end
    clock=clock+dt
    saveClock=saveClock+dt
    if clock >= 0.1 then clock=0; updateProgressText() end
    if saveClock >= 10 then saveClock=0; persistProgression(true) end
end
function goodNoteHit(id,direction,noteType,isSustainNote)
    if getVar('ftk_phase') ~= 'play' then return end
    if getPropertyFromGroup('notes',id,'hitCausesMiss') == true then return end
    if isSustainNote then gainExperience(xpForNote(1))
    else
        local base=1
        if getProperty('cpuControlled') ~= true then
            local rating=tostring(getPropertyFromGroup('notes',id,'rating') or 'sick'):lower()
            base=XP_BY_RATING[rating] or 0
        end
        gainExperience(xpForNote(base))
    end
end
function onEndSong() persistProgression(true) return Function_Continue end
function onDestroy() persistProgression(true) end
