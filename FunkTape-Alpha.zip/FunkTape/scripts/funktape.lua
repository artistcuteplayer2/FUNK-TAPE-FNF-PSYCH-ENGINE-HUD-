local CONFIG = {
    points = {sick = 4, good = 3, bad = 2, shit = 1, miss = 0},
    -- Stars are based on score / baseline MAX SCORE. Score itself is NEVER capped.
    starThresholds = {0.20, 0.40, 0.60, 0.80, 1.00},
    refreshSeconds = 0.10,
    hideOriginalJudgement = true, -- use fixed judgement images and counts
    showJudgementDeck = true,
    countBotplayScore = true, -- accuracy remains 0% on any bot-assisted track
    botplayPoints = 1, -- every successful bot head or sustain tick earns 1 point
    sustainPoints = 1, -- each successfully held sustain tick earns 1 point
    allowRetryOnResults = true,
    -- Story Mode only: wait on each intermediate track result, then ask
    -- the native Psych Engine to advance. No auto-exit on the WEEK finale.
    storyAutoAdvanceSeconds = 9,
    -- Visual effects: no particles, shaders, camera zooms or runtime textures.
    visualEffects = true,
}
-- IMPORTANT: non-standard custom note scoring / chart-mutating Lua scripts can
-- change actual score independently. The baseline MAX only counts standard
-- scoreable player heads and sustain ticks existing at onCreatePost.
-- =======================================================================

local SAVE = 'funktape_v4_records' -- shared with v4: preserve existing records
local phase = 'play' -- play -> result -> release
local story = false
local downScroll = false
local hiddenByPlayer = false
local trackCount = 1
local trackNumber = 1
local remaining = 1
local week = 0
local difficulty = 1
local priorMax = 0
local priorNotes = 0
local priorPlayed = 0
local priorHitWeight = 0
local priorBestCombo = 0
local usedBotplay = false
local priorBotplay = false
local priorJudgements = {0, 0, 0, 0}
local judgementNames = {'sick', 'good', 'bad', 'shit'}
local baseNotes = 0
local baseSustainTicks = 0
local maxScore = 0
-- WEEK-wide chart baseline: previous tracks + current track + remaining tracks.
-- If future chart discovery fails, the visible value is marked as partial.
local weekMaxScore = 0
local weekMaxComplete = false
local weekHistoryComplete = true
local maxPerNote = 350
local lastMissCount = 0
local bestCombo = 0
local clock = 0
local sprites = {}
local texts = {}
local hudTexts = {}
local hudTextLimits = {}
local hudShell = ''
local trackKey = ''
local weekKey = ''
-- Native Psych character icon art remains engine-owned; visual pose is fixed.
-- Their layout position is overridden for the original BATTLE CARTRIDGE UI.
local cfgProfile = ''
local downLayer = false
local lastHealth = -1
local lastProgress = -1
local starCount = -1
local starStageFraction = -1 -- cached live progress, draw only on changes
local savedHudVisibility = {}
local gaugeX = 440
local gaugeY = 627
local gaugeWidth = 400
local gaugeMode = 'split'
local progressY = 19
local progressWidth = 278
local progressX = 502
local iconTop = 520
local starTags = {} -- starTags[i] is a set of five procedural line sprites
local footerOffset = 0
local comboFlashCooldown = 0
local resultUIWait = 0

local function number(v, default)
    local n = tonumber(v)
    if n == nil or n ~= n then return default or 0 end
    return n
end
local function round(n) return n >= 0 and math.floor(n + 0.5) or math.ceil(n - 0.5) end
local function clamp(v, low, high) return math.max(low, math.min(high, v)) end
local function commas(v)
    local n = round(number(v, 0))
    local neg = n < 0 and '-' or ''
    local s = tostring(math.abs(n))
    s = s:reverse():gsub('(%d%d%d)', '%1,'):reverse():gsub('^,', '')
    return neg .. s
end
local function truncate(text, length)
    text = tostring(text or 'UNKNOWN')
    return #text > length and (text:sub(1, length - 2) .. '..') or text
end
local function currentSong()
    return tostring(songName or loadedSongName or 'UNKNOWN')
end
local function songDifficultyCaption(length)
    local index = tonumber(getPropertyFromClass('states.PlayState', 'storyDifficulty')) or difficulty
    -- Resolve the actual Week difficulty list, including Normal-only/custom lists.
    local name = getPropertyFromClass('backend.Difficulty', 'list[' .. index .. ']')
    name = tostring(name or 'Normal'):match('^%s*(.-)%s*$')
    if name == '' then name = 'Normal' end
    local suffix = ' - ' .. truncate(name:upper(), math.max(8, length - 11))
    return truncate(currentSong():upper(), math.max(8, length - #suffix)) .. suffix
end
local function makeName(s)
    return tostring(s or 'none'):lower():gsub('[^%w_%-]', '_')
end
local function getC(name, fallback)
    local value = getPropertyFromClass('states.PlayState', name)
    if value == nil then return fallback end
    return value
end
local function getP(name, fallback)
    local value = getProperty(name)
    if value == nil then return fallback end
    return value
end
local function noteBotUsage()
    if getP('cpuControlled', false) == true then usedBotplay = true end
end
local function forceBotAccuracy()
    noteBotUsage()
    if usedBotplay then
        setRatingPercent(0)
        setRatingName('BOTPLAY')
        setRatingFC('')
    end
end
local function getSave(k, fallback)
    local v = getDataFromSave(SAVE, k, fallback)
    if v == nil then return fallback end
    return v
end
local function save(k, v) setDataFromSave(SAVE, k, v) end
local function screenY(y, height)
    return downScroll and (720 - y - (height or 0)) or y
end
-- Keep every gameplay deck element BEHIND native notes, receptors, icons
-- and judgement popups. Prevents dark HUD cards from obscuring arrows.
-- Gameplay HUD belongs to camHUD, result UI to camOther. Avoid moving
-- objects relative to uiGroup: it can reorder them behind the stage on some
-- Psych forks and is not a stable anchor across all PlayState layouts.
local function layerUnderNative(tag, camera)
    if camera ~= 'hud' then return end
    local anchor = getObjectOrder('strumLineNotes')
    if type(anchor) == 'number' and anchor >= 0 then
        setObjectOrder(tag, anchor)
    end
end
local function makeImage(tag, image, x, y, camera)
    makeLuaSprite(tag, 'funktape/' .. image, x, y)
    addLuaSprite(tag, true)
    setObjectCamera(tag, camera or 'hud')
    layerUnderNative(tag, camera)
    sprites[#sprites+1] = tag
    return tag
end
-- Typography: three mutually distinct visual roles. No font is embedded.
-- Three OFL font files are bundled in FunkTape/fonts/; Comfortaa-Bold.ttf stays on progression.
-- headline : big, condensed song and countdown headers (Wolpe Fanfare).
-- award    : achievement/status captions (Albertus Nova).
-- ui       : fast-reading numbers, gauges, stats and guidance (Shag Lounge).
local FONT = {
    headline = 'NotoSansDisplay-CondensedBlack.ttf',
    award = 'NotoSerifDisplay-Bold.ttf',
    ui = 'Lato-Bold.ttf'
}
local FONT_ROLE_BY_TAG = {
    ftk_song = 'headline',
    ftk_badge = 'award',
    ftk_topline = 'award'
    -- All other gameplay HUD labels (including score/accuracy/remaining
    -- points/combo/judgement counts) intentionally use FONT.ui.
}
local function labelFont(tag)
    return FONT[FONT_ROLE_BY_TAG[tag] or 'ui']
end

local function makeLabel(tag, value, x, y, width, size, color, align, camera)
    makeLuaText(tag, tostring(value or ''), width, x, y)
    setTextSize(tag, size or 20)
    setTextColor(tag, color or 'FFFFFF')
    setTextFont(tag, labelFont(tag))
    if align then setTextAlignment(tag, align) end
    -- 2px dark outline preserves readability over high-contrast gameplay backgrounds.
    setTextBorder(tag, 3, '050813')
    addLuaText(tag)
    setObjectCamera(tag, camera or 'hud')
    layerUnderNative(tag, camera)
    texts[#texts+1] = tag
    return tag
end
local function hudLabel(tag, value, x, y, width, size, color, align)
    if y >= 588 then y = y + footerOffset end
    hudTexts[tag] = tostring(value)
    hudTextLimits[tag] = {width = width, size = size or 20}
    return makeLabel(tag, value, x, y, width, size, color, align, 'hud')
end
local function editLabel(tag, value)
    if not tag then return end
    value = tostring(value)
    if hudTexts[tag] ~= value then
        hudTexts[tag] = value
        setTextString(tag, value)
        local limit = hudTextLimits[tag]
        if limit then
            -- Font-specific advance ratios: Wolpe condensed; Albertus wide;
            -- Shag Lounge medium. Adjust text SIZE only (never the HUD layout).
            local role = FONT_ROLE_BY_TAG[tag] or 'ui'
            local advance = role == 'headline' and 0.38 or (role == 'award' and 0.75 or 0.57)
            local fit = math.floor((limit.width - 6) / math.max(1, #value) / advance)
            -- Never miniaturize critical numeric HUD readouts to unreadable glyphs.
            -- Dynamic song titles still fit independently within their fixed card.
            local floorSize = (tag == 'ftk_song') and 10 or
                ((tag == 'ftk_star_next') and 11 or 9)
            setTextSize(tag, math.max(7, math.min(limit.size, math.max(floorSize, fit), fit)))
        end
    end
end
local function computeStars(score, max)
    if max <= 0 then return 0, 0, false end
    local ratio = score / max -- intentionally UNCLAMPED; over 100% is valid
    local count = 0
    for _, minFraction in ipairs(CONFIG.starThresholds) do
        if ratio + 0.00000001 >= minFraction then count = count + 1 end
    end
    return count, ratio, ratio > 1.00000001
end
-- The thresholds below are exactly the thresholds used by computeStars.
-- An integer target must obey computeStars' small floating-point tolerance.
-- The MAX baseline is never a cap on earned score.
local function starMilestone(score, baseline, currentStars)
    if baseline <= 0 then return 0, 0, 0, 0 end
    if currentStars >= #CONFIG.starThresholds then
        return #CONFIG.starThresholds, 0, 0, 1
    end
    local eps = 0.00000001
    local previous = currentStars == 0 and 0 or
        math.max(0, math.ceil((CONFIG.starThresholds[currentStars] - eps) * baseline))
    local upcoming = math.max(0, math.ceil((CONFIG.starThresholds[currentStars + 1] - eps) * baseline))
    local remainingPoints = math.max(0, math.ceil(upcoming - score))
    local fraction = clamp((score - previous) / math.max(1, upcoming - previous), 0, 1)
    return currentStars + 1, upcoming, remainingPoints, fraction
end

local function pointsSignature()
    local p = CONFIG.points
    return table.concat({p.sick,p.good,p.bad,p.shit,p.miss},'_') .. '_bot' .. CONFIG.botplayPoints .. '_hold' .. CONFIG.sustainPoints
end
local function selectMode()
    story = isStoryMode == true or getC('isStoryMode', false) == true
    week = number(getC('storyWeek', 0), 0)
    difficulty = number(getC('storyDifficulty', 1), 1)
    remaining = story and number(getC('storyPlaylist.length', 1), 1) or 1
    if remaining < 1 then remaining = 1 end
    downScroll = getPropertyFromClass('backend.ClientPrefs', 'data.downScroll') == true
    footerOffset = downScroll and -164 or 0
    hiddenByPlayer = getPropertyFromClass('backend.ClientPrefs', 'data.hideHud') == true
    downLayer = downScroll
    cfgProfile = pointsSignature()
    trackKey = 'track_' .. makeName(currentSong()) .. '_' .. tostring(difficulty) .. '_' .. cfgProfile
    weekKey = 'week_' .. tostring(week) .. '_' .. tostring(difficulty) .. '_' .. cfgProfile
end
local function findStoryCheckpoint()
    trackCount = remaining
    trackNumber = 1
    if not story then return end
    local nativeSum = number(getC('campaignScore', 0), 0)
    weekHistoryComplete = true
    local valid = getSave('next_valid', false) == true
    -- Check all identifying fields to prevent stale Week / retry cross-contamination.
    local match = valid and
        number(getSave('next_week', -1), -1) == week and
        number(getSave('next_diff', -1), -1) == difficulty and
        number(getSave('next_left', -1), -1) == remaining and
        number(getSave('next_campaign', -123456789), -123456789) == nativeSum and
        tostring(getSave('next_song', '')):lower() == currentSong():lower() and
        tostring(getSave('next_profile', '')) == cfgProfile
    if match then
        trackNumber = number(getSave('completed', 0), 0) + 1
        trackCount = trackNumber + remaining - 1
        priorMax = number(getSave('prior_max', 0), 0)
        priorNotes = number(getSave('prior_notes', 0), 0)
        priorPlayed = number(getSave('prior_played', 0), 0)
        priorHitWeight = number(getSave('prior_hitweight', 0), 0)
        priorBestCombo = number(getSave('prior_bestcombo', 0), 0)
        priorBotplay = getSave('prior_botplay', false) == true
        for i = 1, 4 do
            priorJudgements[i] = number(getSave('prior_judgement_' .. i, 0), 0)
        end
    else
        -- Only a zero native campaign score can safely start a fresh Week.
        -- Otherwise the engine has previous results we cannot reconstruct.
        weekHistoryComplete = nativeSum == 0
        save('next_valid', false)
    end
end
local function saveStoryCheckpoint()
    if not story then return end
    if remaining <= 1 then
        save('next_valid', false)
        return
    end
    local nextSong = getC('storyPlaylist[1]', '')
    save('next_valid', true)
    save('next_week', week)
    save('next_diff', difficulty)
    save('next_left', remaining - 1)
    save('next_campaign', number(getC('campaignScore', 0), 0) + number(getP('songScore', 0), 0))
    save('next_song', tostring(nextSong or ''))
    save('next_profile', cfgProfile)
    save('completed', trackNumber)
    save('prior_max', priorMax + maxScore)
    save('prior_notes', priorNotes + baseNotes + baseSustainTicks)
    save('prior_played', priorPlayed + number(getP('totalPlayed', 0), 0))
    save('prior_hitweight', priorHitWeight + number(getP('totalNotesHit', 0), 0))
    save('prior_bestcombo', math.max(priorBestCombo, bestCombo))
    save('prior_botplay', priorBotplay or usedBotplay)
    for i = 1, 4 do
        save('prior_judgement_' .. i, priorJudgements[i] +
            number(getPropertyFromGroup('ratingsData', i - 1, 'hits'), 0))
    end
end
local function applyRatingPoints()
    local names = {'sick','good','bad','shit'}
    local old
    for i, name in ipairs(names) do
        local n = math.max(0, round(number(CONFIG.points[name], 0)))
        CONFIG.points[name] = n
        setPropertyFromGroup('ratingsData', i - 1, 'score', n)
        old = number(getPropertyFromGroup('ratingsData', i - 1, 'score'), -1)
        if old ~= n then debugPrint('[FunkTape] rating write failed: ' .. name) end
    end
    CONFIG.points.miss = round(number(CONFIG.points.miss, -10))
    CONFIG.sustainPoints = math.max(0, round(number(CONFIG.sustainPoints, 1)))

    local pointadjust = 0

    if difficulty == 0 then
        pointadjust = CONFIG.points.shit
    elseif difficulty == 1 then
        pointadjust = CONFIG.points.bad
    else
        pointadjust = CONFIG.points.good
    end

    maxPerNote = pointadjust
end
local function scoreDifficultyFactor()
    if difficulty == 0 then return 0.75 end
    if difficulty == 1 then return 1 end
    return 1.1
end

local function countNotes()
    -- Scoreable player heads and sustain ticks present at onCreatePost.
    -- A rating-disabled note can still score in Psych 1.0.4, so it is INCLUDED.
    local n = number(getP('unspawnNotes.length', 0), 0)
    -- Short-circuit per-note property reads without changing scoreable-note rules.
    -- Opponent notes need no sustain/hurt reads; hazard notes need no sustain read.
    -- Do NOT move this pass, switch to unverified Haxe bulk counting or change MAX.
    for i = 0, n - 1 do
        if getPropertyFromGroup('unspawnNotes', i, 'mustPress') == true
            and getPropertyFromGroup('unspawnNotes', i, 'hitCausesMiss') ~= true then
            if getPropertyFromGroup('unspawnNotes', i, 'isSustainNote') == true then
                baseSustainTicks = baseSustainTicks + 1
            else
                baseNotes = baseNotes + 1
            end
        end
    end

    local scoreold = (baseNotes * maxPerNote + baseSustainTicks * CONFIG.sustainPoints)
        * scoreDifficultyFactor()

    local newscore = math.ceil(scoreold)

    maxScore = newscore
end
-- The current chart's MAX comes from already-generated unspawnNotes.
-- Remaining tracks have not been generated yet: read ONLY their chart data.
-- Song.getChart (unlike Song.loadFromJson) does NOT replace PlayState.SONG,
-- change loadedSongName, or start another song. This is a one-time load per track.
local function calculateWeekMax()
    weekMaxScore = priorMax + maxScore
    weekMaxComplete = weekHistoryComplete
    if not story or remaining <= 1 then return end

    -- Establish a deterministic fallback BEFORE running the optional reader.
    setVar('ftk_week_future_ok', false)
    setVar('ftk_week_future_max', 0)
    setVar('ftk_week_head_points', maxPerNote)
    setVar('ftk_week_hold_points', CONFIG.sustainPoints)
    setVar('ftk_week_difficulty_factor', scoreDifficultyFactor())

    -- Class registrations are made once, not inside gameplay/update loops.
    local loaded = pcall(function()
        addHaxeLibrary('Song', 'backend')
        addHaxeLibrary('Difficulty', 'backend')
        addHaxeLibrary('StringMap', 'haxe.ds')
        runHaxeCode([[
            var futureScore:Float = 0;
            var valid:Bool = true;
            var playlist = PlayState.storyPlaylist;
            var suffix = Difficulty.getFilePath();
            var headPoints:Float = Std.parseFloat(Std.string(getVar('ftk_week_head_points')));
            var holdPoints:Float = Std.parseFloat(Std.string(getVar('ftk_week_hold_points')));
            var difficultyFactor:Float = Std.parseFloat(Std.string(getVar('ftk_week_difficulty_factor')));
            if (playlist == null || playlist.length <= 1 ||
                Math.isNaN(headPoints) || Math.isNaN(holdPoints) || Math.isNaN(difficultyFactor)) {
                valid = false;
            } else {
                for (index in 1...playlist.length) {
                    try {
                        var songName = playlist[index];
                        var chart = Song.getChart(songName + suffix, songName);
                        if (chart == null || chart.notes == null || chart.bpm <= 0) {
                            valid = false;
                            break;
                        }
                        var headCount:Int = 0;
                        var holdCount:Int = 0;
                        var bpm:Float = chart.bpm;
                        // Psych 1.0.4 generateSong() removes prior duplicates of
                        // identical time/lane/side/type (except first in section).
                        // This map stores previous scoreable head/hold contributions.
                        var seen = new StringMap();
                        for (section in chart.notes) {
                            if (section.changeBPM == true && section.bpm != null && section.bpm > 0)
                                bpm = section.bpm;
                            if (bpm <= 0 || section.sectionNotes == null) {
                                valid = false;
                                break;
                            }
                            var step:Float = 15000.0 / bpm;
                            for (n in 0...section.sectionNotes.length) {
                                var note = section.sectionNotes[n];
                                var lane = Std.int(note[1]);
                                var playable:Bool = lane >= 0 && lane < 4;
                                var typeName:String = '';
                                if (Std.isOfType(note[3], String)) typeName = note[3];
                                else if (note[3] != null) {
                                    var typeIndex = Std.int(note[3]);
                                    if (typeIndex >= 0 && typeIndex < Note.defaultNoteTypes.length)
                                        typeName = Note.defaultNoteTypes[typeIndex];
                                }
                                // Unknown custom types can change hitCausesMiss
                                // through external scripts/config; do not assert a full MAX.
                                if (typeName != '' && typeName != 'Alt Animation' &&
                                    typeName != 'Hey!' && typeName != 'Hurt Note' &&
                                    typeName != 'GF Sing' && typeName != 'No Animation') {
                                    valid = false;
                                    break;
                                }
                                var holdLength:Float = Std.parseFloat(Std.string(note[2]));
                                if (Math.isNaN(holdLength)) holdLength = 0;
                                var holdSegments:Int = Math.max(0, Math.round(holdLength / step));
                                var scoreable:Bool = playable && typeName != 'Hurt Note';
                                var head:Int = scoreable ? 1 : 0;
                                var holds:Int = scoreable ? holdSegments : 0;
                                var key = Std.string(note[0]) + '|' + Std.string(lane % 4) +
                                    '|' + Std.string(playable) + '|' + typeName;
                                var previous = seen.get(key);
                                if (n > 0 && previous != null) {
                                    headCount -= previous[0];
                                    holdCount -= previous[1];
                                }
                                headCount += head;
                                holdCount += holds;
                                seen.set(key, [head, holds]);
                            }
                        }
                        if (!valid) break;
                        futureScore += Math.ceil((headCount * headPoints +
                            holdCount * holdPoints) * difficultyFactor);
                    } catch (e:Dynamic) {
                        valid = false;
                        break;
                    }
                }
            }
            setVar('ftk_week_future_ok', valid);
            setVar('ftk_week_future_max', valid ? futureScore : 0);
        ]])
    end)

    if loaded and getVar('ftk_week_future_ok') == true then
        local future = number(getVar('ftk_week_future_max'), -1)
        if future >= 0 and future < math.huge then
            weekMaxScore = weekMaxScore + future
            return
        end
    end
    -- Never present an unverified incomplete maximum as a whole-week maximum.
    weekMaxComplete = false
    debugPrint('[FunkTape] Could not inspect all remaining charts; using MAX SO FAR')
end

local function scoreBaseline()
    if story then return weekMaxScore end
    return maxScore
end

-- The Psych icons are real HealthIcon instances, not static BF/DAD pictures.
-- We replace the entire *visual layout* of the native HUD.  The game still
-- owns the health calculation, note scoring, icon frames and character swaps.
local function configureNativeHud()
    for _, name in ipairs({'healthBar', 'scoreTxt', 'timeBar', 'timeTxt', 'botplayTxt'}) do
        savedHudVisibility[name] = getP(name .. '.visible', false)
        setProperty(name .. '.visible', false)
    end
    -- Native icons remain engine-owned and will be locked below.
    if CONFIG.hideOriginalJudgement then
        setProperty('showRating', false)
        setProperty('showCombo', false)
        setProperty('showComboNum', false)
    end
end
-- HUD-only positioning. Native notes and the camera viewport are not moved.
-- Downscroll statistics sit above the native bottom receptors.
local function makeRect(tag, x, y, w, h, color)
    makeLuaSprite(tag, nil, x, y)
    makeGraphic(tag, w, h, color)
    addLuaSprite(tag, true)
    setObjectCamera(tag, 'hud')
    layerUnderNative(tag, 'hud')
    sprites[#sprites + 1] = tag
    return tag
end
-- Engine-owned icons: preserve character art and swaps, but leave their
-- camera alone. Changing cameras to camOther breaks native HUD grouping and
-- can produce UI priority problems in substates such as Pause.
local ICON_X = {P1 = 1145, P2 = 32}
local ICON_SCALE = 0.35
local function lockNativeIcons()
    if hiddenByPlayer or phase ~= 'play' then return end
    for _, side in ipairs({'P1', 'P2'}) do
        local tag = 'icon' .. side
        setProperty(tag .. '.visible', true)
        setProperty(tag .. '.x', ICON_X[side])
        setProperty(tag .. '.y', 538) -- side lane, aligned under RIVAL/YOU labels
        setProperty(tag .. '.scale.x', ICON_SCALE)
        setProperty(tag .. '.scale.y', ICON_SCALE)
        setProperty(tag .. '.angle', 0)
        setProperty(tag .. '.alpha', 1)
        -- Do not override animation.curAnim.curFrame: Psych Engine selects
        -- winning / losing expressions from the current health value.
    end
end
local function placeIcons()
    if hiddenByPlayer then
        setProperty('iconP1.visible', false)
        setProperty('iconP2.visible', false)
        return
    end
    -- Native character icons stay below their labels; independent of the health bar.
    -- No Haxe camera reassignment, no extra HealthIcon instances.
    lockNativeIcons()
end
local function setFill(tag, left, y, originalWidth, fraction)
    fraction = clamp(fraction, 0, 1)
    setProperty(tag .. '.scale.x', math.max(0.0001, fraction))
    setProperty(tag .. '.x', left - (originalWidth * (1 - fraction)) / 2)
    setProperty(tag .. '.y', y)
    setProperty(tag .. '.visible', fraction > 0.001)
end
-- Gameplay readability uses text outlines, NEVER screen-covering plates.
-- HUD v10: fixed non-overlapping information zones. No full-screen panels.
-- x 32..410: title, mode and star ladder; x 880..1248: score only.
-- x 430..850: note lanes (no stat text); bottom judgement ribbon y 588..630.
-- side gutters house engine HealthIcons; progression controls its own region.
-- Five-point stars drawn as five narrow rotated rectangles each.
-- This uses NO image assets; missing funktape/star_on/off can never render
-- Flixel's multicolor missing-graphic checkerboard again.
local function createHudStar(index, centerX, centerY, radius)
    local vertex = {}
    for j = 0, 4 do
        local a = -math.pi / 2 + (2 * math.pi * j / 5)
        vertex[j + 1] = {centerX + radius * math.cos(a), centerY + radius * math.sin(a)}
    end
    local items = {}
    for j = 1, 5 do
        local v, w = vertex[j], vertex[((j + 1) % 5) + 1]
        local dx, dy = w[1] - v[1], w[2] - v[2]
        local length = math.sqrt(dx * dx + dy * dy)
        local theta = math.atan2 and math.atan2(dy, dx) or math.atan(dy / (math.abs(dx) < 0.00001 and 0.00001 or dx))
        if not math.atan2 and dx < 0 then theta = theta + math.pi end
        local tag = 'ftk_star_' .. index .. '_edge_' .. j
        local thick = 2
        makeLuaSprite(tag, nil, (v[1] + w[1]) / 2 - length / 2,
            (v[2] + w[2]) / 2 - thick / 2)
        makeGraphic(tag, math.max(1, math.floor(length + 0.5)), thick, 'FFFFFF')
        setProperty(tag .. '.angle', math.deg(theta))
        setProperty(tag .. '.color', getColorFromHex('62768F'))
        setObjectCamera(tag, 'other')
        addLuaSprite(tag, true)
        sprites[#sprites + 1] = tag
        items[#items + 1] = tag
    end
    return items
end
local STAR_BAR_X, STAR_BAR_Y, STAR_BAR_W = 44, 139, 348
local function createCommonHud()
    progressX, progressY, progressWidth = 503, 30, 274
    makeRect('ftk_progress_bg', progressX, progressY, progressWidth, 5, '34445D')
    makeRect('ftk_progress_fill', progressX, progressY, progressWidth, 5, 'FCE773')
    makeRect('ftk_star_stage_bg', STAR_BAR_X, STAR_BAR_Y, STAR_BAR_W, 5, '34445D')
    makeRect('ftk_star_stage_fill', STAR_BAR_X, STAR_BAR_Y, STAR_BAR_W, 5, 'FFE18C')
    gaugeX, gaugeY, gaugeWidth = 432, 685 + footerOffset, 416
    makeRect('ftk_health_bg', gaugeX - 2, gaugeY - 2, gaugeWidth + 4, 12, '7E8A9E')
    makeRect('ftk_opp_fill', gaugeX, gaugeY, gaugeWidth, 8, 'FD5B86')
    makeRect('ftk_me_fill', gaugeX, gaugeY, gaugeWidth, 8, '68DDE1')
    for i = 1, 5 do
        starTags[i] = createHudStar(i, 57 + (i - 1) * 34, 86, 10)
    end
    placeIcons()
end
local function createSharedHud()
    createCommonHud()
    hudLabel('ftk_badge', '', 44, 8, 150, 13, 'FFD1E0')
    hudLabel('ftk_meta', '', 212, 8, 193, 12, 'DCE7FA')
    hudLabel('ftk_song', '', 44, 31, 362, 24, 'FFFFFF')
    editLabel('ftk_song', songDifficultyCaption(58))
    hudLabel('ftk_topline', '0 / 5', 242, 76, 148, 18, 'FFE18C', 'right')
    hudLabel('ftk_star_next', 'NEXT STAR 1/5  NEED +0', 44, 108, 349, 16, 'FFE18C')
    hudLabel('ftk_time', '00:00 / 00:00', 551, 4, 180, 16, 'FFFFFF', 'center')
    hudLabel('ftk_score_tag', story and (weekMaxComplete and 'TOTAL SCORE / WEEK MAX SCORE' or 'TOTAL SCORE / MAX SO FAR') or 'SCORE / MAX SCORE', 930, 5, 310, 13, '93F4FF', 'right')
    hudLabel('ftk_score', '0 / ' .. commas(maxScore), 930, 23, 310, 25, 'FFFFFF', 'right')
    -- All lower captions occupy isolated rows instead of floating over icons.
    hudLabel('ftk_perf_tag', 'ACCURACY / MISSES', 206, 632, 250, 14, 'FFC1D6')
    hudLabel('ftk_perf', '0.00% / 00', 206, 652, 250, 20, 'FFFFFF')
    hudLabel('ftk_judge', 'PERFORMANCE UNRATED', 470, 632, 340, 14, 'FFE18C', 'center')
    hudLabel('ftk_health', 'BATTLE PRESSURE', 470, 652, 340, 12, 'D6E5F9', 'center')
    hudLabel('ftk_status', 'STANDARD', 930, 652, 205, 14, 'DCF1FF', 'right')
    hudLabel('ftk_combo', 'BEST 0', 930, 632, 205, 18, 'FFFFFF', 'right')
    hudLabel('ftk_oppname', 'RIVAL', 35, 517, 110, 14, 'FFA9C5', 'center')
    hudLabel('ftk_me_name', 'YOU', 1137, 517, 110, 14, 'A6F4FF', 'center')
    if story then
        editLabel('ftk_badge', 'STORY MODE')
        if trackNumber == trackCount then
            editLabel('ftk_meta', string.format('WEEK %02d - FINAL TRACK!', week + 1))
        else
            editLabel('ftk_meta', string.format('WEEK %02d - TRACK %02d OF %02d', week + 1, trackNumber, trackCount))
        end
    else
        editLabel('ftk_badge', 'FREEPLAY')
        editLabel('ftk_meta', 'PLAYING...')
    end
end
local function createJudgementDeck()
    if not CONFIG.showJudgementDeck then return end
    local stageUI = tostring(getC('stageUI', 'normal'))
    local prefix = stageUI == 'normal' and '' or tostring(getC('uiPrefix', '')) .. 'UI/'
    local suffix = tostring(getC('uiPostfix', ''))
    -- Four columns fit inside 225..815; each icon/count pair owns 135px.
    for i, name in ipairs(judgementNames) do
        local x = 214 + (i - 1) * 138
        local y = 590 + footerOffset
        local tag = 'ftk_judgement_' .. name
        local image = tostring(getPropertyFromGroup('ratingsData', i - 1, 'image') or name)
        makeLuaSprite(tag, prefix .. image .. suffix, x, y)
        local w = math.max(1, number(getProperty(tag .. '.width'), 1))
        local h = math.max(1, number(getProperty(tag .. '.height'), 1))
        local scale = math.min(58 / w, 25 / h)
        scaleObject(tag, scale, scale)
        setProperty(tag .. '.x', x + (58 - w * scale) / 2)
        setProperty(tag .. '.y', y + (25 - h * scale) / 2)
        addLuaSprite(tag, true)
        setObjectCamera(tag, 'hud')
        layerUnderNative(tag, 'hud')
        sprites[#sprites + 1] = tag
        hudLabel('ftk_count_' .. name, 'x 0', x + 60, 594, 68, 18, 'FFFFFF', 'right')
    end
    hudLabel('ftk_live_combo', 'COMBO 0', 805, 593, 132, 18, 'FFE18C', 'center')
end
local function createFreeplayHud() createSharedHud() end
local function createStoryHud() createSharedHud() end
local function timeStamp(ms)
    local sec = math.max(0, math.floor(number(ms,0)/1000))
    return string.format('%02d:%02d',math.floor(sec/60),sec%60)
end
local function updateGauges(force)
    if hiddenByPlayer or phase ~= 'play' then return end
    local health = clamp(number(getP('health',1),1),0,2)
    if force or math.abs(health-lastHealth)>0.002 then
        -- At 1.0 health the line is split 50/50, and moves WITHOUT a cap.
        local opp = 1-health/2
        local me = 1-opp
        setFill('ftk_opp_fill',gaugeX,gaugeY,gaugeWidth,opp)
        setFill('ftk_me_fill',gaugeX+gaugeWidth*opp,gaugeY,gaugeWidth,me)
        lastHealth=health
    end
    local length = number(getP('songLength', number(songLength, 0)),0)
    local ms = number(getSongPosition(),0)
    if ms<0 then ms=0 end
    local progress = length>0 and clamp(ms/length,0,1) or 0
    if force or math.abs(progress-lastProgress)>0.003 then
        setFill('ftk_progress_fill',progressX,progressY,progressWidth,progress)
        lastProgress=progress
    end
    editLabel('ftk_time', timeStamp(ms)..' / '..timeStamp(length))
end
local function updateStars(count)
    if count == starCount then return end
    local oldCount = starCount
    starCount = count
    for i = 1, 5 do
        local active = i <= count
        for j, tag in ipairs(starTags[i]) do
            setProperty(tag .. '.color', getColorFromHex(active and 'FFE18C' or '62768F'))
            if CONFIG.visualEffects and oldCount >= 0 and i > oldCount and active then
                setProperty(tag .. '.alpha', 0.38)
                doTweenAlpha('ftk_star_acquired_' .. i .. '_' .. j, tag, 1, 0.32, 'quadOut')
            end
        end
    end
    if CONFIG.visualEffects and oldCount >= 0 and count > oldCount then
        setProperty('ftk_topline.alpha', 0.35)
        doTweenAlpha('ftk_star_count_glow', 'ftk_topline', 1, 0.35, 'quadOut')
    end
end
local function readAccuracy()
    if usedBotplay then return 0 end
    return clamp(number(getP('ratingPercent', 0), 0), 0, 1) * 100
end
local function statusText()
    local mode = usedBotplay and 'Computer' or
        (getP('practiceMode', false) == true and 'PRACTICE' or 'STANDARD')
    return mode
end
-- Separate judgement *quality* from FC status. No extra score is awarded.
-- Names here are FUNK//TAPE display tiers; underlying Psych rating remains intact.
local function judgementHits()
    local hits = {}
    for i=1,4 do hits[i] = number(getPropertyFromGroup('ratingsData',i-1,'hits'),0) end
    return hits
end
local function performanceTier(accuracy, played)
    if played <= 0 then return 'UNRATED' end
    if accuracy >= 99.95 then return 'FLAWLESS' end
    if accuracy >= 99 then return 'MASTER' end
    if accuracy >= 97 then return 'ELITE' end
    if accuracy >= 93 then return 'EXCELLENT' end
    if accuracy >= 85 then return 'GREAT' end
    if accuracy >= 75 then return 'SOLID' end
    if accuracy >= 60 then return 'STEADY' end
    if accuracy >= 40 then return 'ROUGH' end
    return 'STRUGGLING'
end
local function comboTier(fc, miss)
    fc = tostring(fc or ''):upper()
    if fc == 'SFC' then return 'PERFECT FULL COMBO!' end
    if fc == 'GFC' then return 'GOOD FULL COMBO' end
    if fc == 'FC' then return 'FULL COMBO' end
    if fc == 'SDCB' then return 'Single Digit Combo Break' end
    if fc == 'CLEAR' then return 'Song Completed' end
    if miss == 0 then return 'NO MISSES' end
    return 'Completed!'
end
local function ratingText()
    if usedBotplay then return 'Automatic Computer' end
    local accuracy = readAccuracy()
    local played = number(getP('totalPlayed',0),0)
    local miss = number(getP('songMisses',0),0)
    local tier = performanceTier(accuracy,played)
    return tier .. ' / ' .. comboTier(getP('ratingFC',''),miss)
end
local function updateHud()
    if hiddenByPlayer or phase ~= 'play' then return end
    local songScore = number(getP('songScore', 0), 0)
    -- Story total: engine campaignScore (completed tracks) + live songScore.
    -- WEEK MAX: completed + current + future charts' difficulty-adjusted max.
    -- Freeplay intentionally keeps its per-song numbers and star ladder.
    local displayScore = story and (number(getC('campaignScore', 0), 0) + songScore) or songScore
    local displayMax = scoreBaseline()
    local missed = number(getP('songMisses', 0), 0)
    local accuracy = readAccuracy()
    local stars, ratio, over = computeStars(displayScore, displayMax)
    local status = statusText()
    editLabel('ftk_score', commas(displayScore) .. ' / ' .. commas(displayMax))
    updateStars(stars)
    editLabel('ftk_judge', usedBotplay and 'Automatic Computer' or 'RATING :  ' .. ratingText())
    editLabel('ftk_perf', usedBotplay and string.format('N/A / %02d', missed) or string.format('%.2f%% / %02d',accuracy,missed))
    editLabel('ftk_combo','BEST '..commas(bestCombo))
    editLabel('ftk_status',status)
    editLabel('ftk_topline',stars..' / 5')
    local nextIndex, _, required, stageFraction = starMilestone(displayScore, displayMax, stars)
    if displayMax <= 0 then
        editLabel('ftk_star_next', 'NEXT STAR  N/A  (NO BASELINE)')
    elseif stars >= 5 then
        local beyond = math.max(0, math.floor(displayScore - displayMax + 0.5))
        editLabel('ftk_star_next', beyond > 0 and
            ('5/5 STARS  |  OVER MAX +' .. commas(beyond)) or 'ALL 5 STARS UNLOCKED')
    else
        editLabel('ftk_star_next', 'NEXT STAR ' .. nextIndex .. '/5  |  NEED +' .. commas(required))
    end
    if math.abs(stageFraction - starStageFraction) > 0.002 then
        setFill('ftk_star_stage_fill', STAR_BAR_X, STAR_BAR_Y, STAR_BAR_W, stageFraction)
        starStageFraction = stageFraction
    end
    if CONFIG.showJudgementDeck then
        for i, name in ipairs(judgementNames) do
            editLabel('ftk_count_' .. name, 'x ' .. commas(getPropertyFromGroup('ratingsData', i - 1, 'hits')))
        end
        editLabel('ftk_live_combo', 'COMBO ' .. commas(getP('combo', 0)))
    end
    updateGauges(false)
end
local function applyMissPoints()
    if phase ~= 'play' then return end
    local misses = number(getP('songMisses',0),0)
    -- Engine deducts 10 by itself. Only the difference is applied once, after
    -- native callback completes. Both bad note and ghost tap are covered.
    if misses > lastMissCount and CONFIG.points.miss ~= -10 then
        addScore((misses-lastMissCount)*(CONFIG.points.miss+10))
    end
    lastMissCount = misses
end
local function saveRecord()
    -- Botplay scores/stars are eligible; practice retains its original exclusion.
    if getP('practiceMode',false) then return end
    local score = number(getP('songScore',0),0)
    local stars = select(1,computeStars(score,maxScore))
    if score > number(getSave(trackKey .. '_score', -1000000000),-1000000000) then
        save(trackKey .. '_score',score)
        save(trackKey .. '_max',maxScore)
    end
    if stars > number(getSave(trackKey .. '_stars',0),0) then save(trackKey .. '_stars',stars) end
    if story and remaining <= 1 then
        local totalScore = number(getC('campaignScore',0),0)+score
        local totalMax = scoreBaseline()
        local weekStars = select(1,computeStars(totalScore,totalMax))
        if totalScore > number(getSave(weekKey .. '_score',-1000000000),-1000000000) then
            save(weekKey .. '_score',totalScore)
            save(weekKey .. '_max',totalMax)
        end
        if weekStars > number(getSave(weekKey .. '_stars',0),0) then save(weekKey .. '_stars',weekStars) end
        if usedBotplay or priorBotplay then
            -- Native song records already accept songScore in 1.0.4. Native Week
            -- score saving skips botplay, so explicitly save the accepted score.
            local weekFile = callMethodFromClass('backend.WeekData', 'getWeekFileName', {})
            if weekFile ~= nil and tostring(weekFile) ~= '' then
                callMethodFromClass('backend.Highscore', 'saveWeekScore', {tostring(weekFile), totalScore, difficulty})
            end
        end
    end
end
local OFFICIAL_WEEK_NAMES = {
    tutorial = 'TUTORIAL', week1 = 'DADDY DEAREST',
    week2 = 'SPOOKY MONTH', week3 = 'PICO', week4 = 'MOMMY MUST MURDER',
    week5 = 'RED SNOW', week6 = 'HATING SIMULATOR', week7 = 'TANKMAN',
    weekend1 = 'DUE DEBTS'
}
local function currentWeekIdentity()
    if not story then return '', '' end
    local ok, file = pcall(callMethodFromClass, 'backend.WeekData', 'getWeekFileName', {})
    local key = ok and tostring(file or ''):lower() or ''
    if key == '' or key == 'nil' then key = 'week' .. tostring(week + 1) end
    local caption = (key == 'tutorial') and 'TUTORIAL' or key:upper():gsub('WEEKEND', 'WEEKEND '):gsub('WEEK', 'WEEK ')
    caption = caption:gsub('%s+', ' ')
    return caption, OFFICIAL_WEEK_NAMES[key] or caption
end
-- Result visuals and result input are owned by funktape_results.lua.
-- This file only publishes a single immutable result snapshot and handles the
-- authorized RETRY / CONTINUE action, preserving the native song-end pipeline.
local function publishResultSnapshot()
    local last = story and remaining <= 1
    local score = number(getP('songScore', 0), 0)
    local combined = number(getC('campaignScore', 0), 0) + score
    -- Story Mode TOTAL SCORE is the native campaign score plus this track;
    -- WEEK MAX spans the entire Week, including not-yet-played tracks.
    local baseline = scoreBaseline()
    local reviewScore = story and combined or score
    local stars, ratio, over = computeStars(reviewScore, baseline)
    local accuracy = readAccuracy()
    local misses = number(getP('songMisses', 0), 0)
    local displayedCombo = bestCombo
    local botInReview = usedBotplay or (last and priorBotplay)
    if last then
        local played = priorPlayed + number(getP('totalPlayed', 0), 0)
        local weighted = priorHitWeight + number(getP('totalNotesHit', 0), 0)
        accuracy = played > 0 and clamp(weighted / played, 0, 1) * 100 or 0
        misses = number(getC('campaignMisses', 0), 0) + misses
        displayedCombo = math.max(priorBestCombo, bestCombo)
    end
    if botInReview then accuracy = 0 end

    local heading = not story and 'SOLO RECORD' or (last and 'WEEK RECORD' or 'WEEK PROGRESS')
    local statement = not story and 'SONG COMPLETED!' or (last and 'WEEK COMPLETED!' or 'STAGE COMPLETED!')
    local detail = ratingText()
    if botInReview then detail = 'BOTPLAY / ACC N/A' end
    local judgements = judgementHits()
    if last then
        for i = 1, 4 do judgements[i] = judgements[i] + priorJudgements[i] end
    end
    local weekId, weekName = currentWeekIdentity()
    local nextSong = (story and not last) and tostring(getC('storyPlaylist[1]', '') or '') or ''
    local weekDetail = ''
    if last then
        weekDetail = string.format('WEEK TOTAL %s  //  %d TRACKS', commas(combined), trackCount)
    elseif story then
        weekDetail = string.format('TRACK %d / %d  //  CAMPAIGN %s', trackNumber, trackCount, commas(combined))
    end

    -- Use individually typed Haxe vars, not a Lua table: portable across Psych forks.
    local snapshot = {
        heading = heading, statement = statement, title = songDifficultyCaption(65),
        detail = detail, week = weekDetail, story = story, last = last,
        weekId = weekId, weekName = weekName, trackNumber = trackNumber,
        trackCount = trackCount, nextSong = nextSong, weekScore = combined,
        weekMax = scoreBaseline(), weekMaxComplete = weekMaxComplete,
        autoSeconds = (story and not last) and CONFIG.storyAutoAdvanceSeconds or 0,
        accent = not story and 'FD5B86' or (last and '68DDE1' or 'FFD65C'),
        score = reviewScore, max = baseline, ratio = ratio, over = over,
        stars = stars, accuracy = accuracy, bot = botInReview, misses = misses,
        combo = displayedCombo, retry = CONFIG.allowRetryOnResults,
        effects = CONFIG.visualEffects,
        nextLabel = not story and 'FREEPLAY' or (last and 'FINISH WEEK' or 'NEXT TRACK')
    }
    for key, value in pairs(snapshot) do setVar('ftk_r_' .. key, value) end
    for i, name in ipairs(judgementNames) do setVar('ftk_r_hit_' .. name, judgements[i]) end
    for i, threshold in ipairs(CONFIG.starThresholds) do
        setVar('ftk_r_star_threshold_' .. i, threshold)
    end

    setProperty('iconP1.visible', false)
    setProperty('iconP2.visible', false)
    for _, tag in ipairs(sprites) do setProperty(tag .. '.visible', false) end
    for _, tag in ipairs(texts) do setProperty(tag .. '.visible', false) end
    setVar('ftk_result_action', 'none')
    setVar('ftk_result_ui_active', false)
    setVar('ftk_result_ready', true) -- commit LAST: renderer cannot see a partial snapshot
end

local function finishResult(retry)
    if phase ~= 'result' then return end
    phase = 'release'
    setVar('ftk_phase', 'release')
    setVar('ftk_result_ready', false)
    if retry then
        restartSong()
    else
        saveRecord()
        if story then saveStoryCheckpoint() end
        flushSaveData(SAVE)
        -- The engine still handles native Highscore, Week totals, playlist advance.
        endSong()
    end
end

-- Text-only countdown. Engine timing and original intro sounds are UNCHANGED.
-- Hide only the engine READY / SET / GO images, never its sound or beat timer.
local countdownPrepared = false
local function hideNativeCountdownImages()
    runHaxeCode([[
        if (game.countdownReady != null) game.countdownReady.visible = false;
        if (game.countdownSet != null) game.countdownSet.visible = false;
        if (game.countdownGo != null) game.countdownGo.visible = false;
    ]])
end
local function setupTextCountdown()
    if countdownPrepared then return end
    makeLuaText('ftk_countdown_text', '', 520, 380, 235)
    setTextSize('ftk_countdown_text', 68)
    setTextAlignment('ftk_countdown_text', 'center')
    setTextColor('ftk_countdown_text', 'FFFFFF')
    setTextBorder('ftk_countdown_text', 3, '111629')
    setTextFont('ftk_countdown_text', FONT.headline)
    addLuaText('ftk_countdown_text')
    setObjectCamera('ftk_countdown_text', 'other')
    setProperty('ftk_countdown_text.visible', false)
    countdownPrepared = true
end
function onCountdownTick(counter)
    if not countdownPrepared then return end
    hideNativeCountdownImages()
    local captions = {[0]='3', [1]='2', [2]='1', [3]='GO!'}
    local caption = captions[counter]
    if caption then
        setTextString('ftk_countdown_text', caption)
        setProperty('ftk_countdown_text.visible', true)
    else
        setProperty('ftk_countdown_text.visible', false)
    end
end
function onSongStart()
    if countdownPrepared then setProperty('ftk_countdown_text.visible', false) end
    hideNativeCountdownImages()
end

function onCreatePost()
    noteBotUsage()
    setVar('ftk_phase', 'play')
    setVar('ftk_result_ready', false)
    setVar('ftk_result_ui_active', false)
    setVar('ftk_result_action', 'none')
    initSaveData(SAVE)
    selectMode()
    findStoryCheckpoint()
    applyRatingPoints()
    countNotes()
    calculateWeekMax()
    lastMissCount = number(getP('songMisses',0),0)
    configureNativeHud()
    setupTextCountdown()
    if not hiddenByPlayer then
        if story then createStoryHud() else createFreeplayHud() end
        createJudgementDeck()
        updateHud()
        updateGauges(true)
    end
end

function onUpdatePost(elapsed)
    forceBotAccuracy()
    if phase == 'result' then
        if getVar('ftk_result_ui_active') ~= true then
            resultUIWait = resultUIWait + number(elapsed, 0)
            if resultUIWait >= 3.0 then
                debugPrint('[FunkTape] Result renderer failed to initialize; native continue')
                finishResult(false) -- never trap the player on a broken result screen
                return
            end
        end
        local action = tostring(getVar('ftk_result_action') or 'none')
        if action == 'continue' or action == 'retry' then
            setVar('ftk_result_action', 'none')
            -- LOOP uses the same ENTER key; never consume its confirmation.
            if (tonumber(getVar('ftk_loop_confirm')) or 0) == 0
                and getVar('ftk_loop_suppress') ~= true then
                finishResult(action == 'retry')
            end
        end
        return
    end
    if phase ~= 'play' then return end
    if countdownPrepared and getP('startingSong', false) then hideNativeCountdownImages() end
    lockNativeIcons()
    -- Leave camHUD.zoom under the engine's control. The fixed HUD is on camOther,
    -- so forcing zoom to 1 every frame is unnecessary and breaks beat effects.
    local dt = number(elapsed, 0)
    comboFlashCooldown = math.max(0, comboFlashCooldown - dt)
    clock=clock+dt
    if clock>=CONFIG.refreshSeconds then
        clock=0
        updateHud()
    end
end

function goodNoteHit(id, direction, noteType, isSustainNote)
    if phase ~= 'play' then return end
    noteBotUsage()
    if isSustainNote then
        -- 1.0.4 calls goodNoteHit once per successfully held segment and does
        -- not assign native score/accuracy/judgement hits for the segment.
        -- Only add its score here; leave head-only accuracy and combo intact.
        if getPropertyFromGroup('notes', id, 'hitCausesMiss') ~= true then
            local bot = getP('cpuControlled', false) == true
            if not bot or CONFIG.countBotplayScore then
                addScore(bot and CONFIG.botplayPoints or CONFIG.sustainPoints)
                forceBotAccuracy()
            end
        end
        return
    end
    if CONFIG.countBotplayScore and getP('cpuControlled', false) == true then
        -- popUpScore already assigned note.rating, ratingMod and judgement hits.
        -- Only score/songHits/totalPlayed are skipped by the engine for botplay.
        -- Do not add a second rating hit or a second totalNotesHit contribution.
        local hurts = getPropertyFromGroup('notes', id, 'hitCausesMiss') == true
        if not hurts then
            local award = CONFIG.botplayPoints
            if award ~= nil then
                if getPropertyFromGroup('notes', id, 'ratingDisabled') ~= true then
                    setProperty('songHits', number(getP('songHits', 0), 0) + 1)
                    setProperty('totalPlayed', number(getP('totalPlayed', 0), 0) + 1)
                end
                addScore(award)
                forceBotAccuracy()
            end
        end
    end
    local combo = number(getP('combo', 0), 0)
    bestCombo = math.max(bestCombo, combo)
    -- A short milestone highlight, capped to one tween every 0.12 s.
    -- Sustains and botplays cannot spawn repeated effects here.
    if CONFIG.visualEffects and not hiddenByPlayer and comboFlashCooldown <= 0
        and combo >= 10 and combo % 10 == 0 then
        comboFlashCooldown = 0.12
        local target = CONFIG.showJudgementDeck and 'ftk_live_combo' or 'ftk_combo'
        setProperty(target .. '.alpha', 0.45)
        doTweenAlpha('ftk_combo_milestone', target, 1, 0.24, 'quadOut')
    end
end
function noteMiss(id, direction, noteType, isSustainNote) applyMissPoints() end
function noteMissPress(direction) applyMissPoints() end

function onEndSong()
    forceBotAccuracy()
    if phase == 'release' then return Function_Continue end
    if phase == 'result' then return Function_Stop end
    -- Installation failsafe: without the separate result script, do not softlock.
    if getVar('ftk_result_module_seen') ~= true then
        debugPrint('[FunkTape] funktape_results.lua missing; continuing natively')
        saveRecord()
        if story then saveStoryCheckpoint() end
        flushSaveData(SAVE)
        phase = 'release'
        setVar('ftk_phase', 'release')
        return Function_Continue
    end
    -- No tape-stop sound or supplementary sound is played.
    phase = 'result'
    resultUIWait = 0
    setVar('ftk_phase', 'result')
    publishResultSnapshot()
    return Function_Stop
end

function onRecalculateRating()
    noteBotUsage()
    if usedBotplay then
        forceBotAccuracy()
        return Function_Stop
    end
    return Function_Continue
end

function onPause()
    if phase == 'result' then return Function_Stop end
    return Function_Continue
end

function onDestroy()
    -- Don't persist partial runs as completed records. Only CONTINUE commits.
    -- Retry restarts without advancing, and native Psych Engine owns all Week saves.
end