# Bundled font credits and permission notices

All four TTF files in `FunkTape/fonts/` are unmodified and distributed under the
SIL Open Font License 1.1 (OFL). See `OFL-1.1.txt` in this directory for its
full text. The copyrights of the fonts remain with their original creators.
Neither the font files nor their font names are relicensed as FUNK//TAPE code.

| UI role | Bundled filename | Replaces |
| --- | --- | --- |
| Large headlines | NotoSansDisplay-CondensedBlack.ttf | Wolpe Fanfare |
| Awards and results | NotoSerifDisplay-Bold.ttf | Albertus Nova |
| Numeric HUD and UI | Lato-Bold.ttf | Shag Lounge |
| LEVEL / XP / LOOP | Comfortaa-Bold.ttf | Arista |

## Original font authors and copyright notices

- **Noto Sans Display / Noto Serif Display**: Copyright 2010, 2012–2020
  Google Inc.; Copyright 2015–2020 Google LLC. OFL-1.1. Original font
  names are retained; no outlines or font metadata were modified.
  Upstream: https://github.com/notofonts
- **Lato**: Copyright (c) 2011–2015 tyPoland Łukasz Dziedzic
  (https://www.latofonts.com/). Reserved Font Name "Lato".
  Licensed under SIL Open Font License 1.1.
- **Comfortaa**: Copyright 2008–2017 Johan Aakerlund
  (aajohan@gmail.com). Reserved Font Name "Comfortaa".
  Licensed under SIL Open Font License 1.1.

These texts are required attribution/license notices for the redistributed
font files. The game, engine and FUNK//TAPE itself remain separate works.
