﻿$ErrorActionPreference = 'Stop'
Write-Host 'Data Delete system' -ForegroundColor Cyan
Write-Host ('Tool folder: ' + $PSScriptRoot)
Write-Host 'This tool permanently delete your save data.'

$active = @(Get-Process -Name 'PsychEngine','ApplicationMain' -ErrorAction SilentlyContinue)
if ($active.Count -gt 0) {
    Write-Host 'Hey! Psych Engine appears to be running. Close the game first' -ForegroundColor Red
    exit 2
}

$saveRoot = Join-Path $env:APPDATA 'ShadowMario\PsychEngine'
if (!(Test-Path -LiteralPath $saveRoot -PathType Container)) {
    Write-Host ('Hey! Expected save folder not found: ' + $saveRoot) -ForegroundColor Yellow
    Write-Host 'Cannot Do That! Check your actual Psych Engine save path'
    exit 3
}

$matches = @(Get-ChildItem -LiteralPath $saveRoot -Filter 'funktape_progression_v1.sol' -File -Recurse -ErrorAction Stop)
if ($matches.Count -eq 0) {
    Write-Host 'Hey! funktape_progression_v1.sol was not found' -ForegroundColor Yellow
    exit 3
}
if ($matches.Count -ne 1) {
    Write-Host 'Hey! Multiple candidate save files found. Choose manually:' -ForegroundColor Yellow
    $matches | ForEach-Object { Write-Host $_.FullName }
    Write-Host 'Cannot Do That!'
    exit 4
}

$target = $matches[0]
Write-Host ('Target: ' + $target.FullName)
Write-Host ('File size: ' + $target.Length + ' bytes')
Write-Host 'Before continuing, the following Mod Settings values MUST be set: RESET REQUEST ID = 0, CONFIRM RESET PROGRESSION = OFF' -ForegroundColor Yellow
Write-Host 'If they are ALREADY 0 / OFF, skip the in-game settings step and continue here. If not, CLOSE this tool, start the game, correct both settings, exit the game, then run it again' -ForegroundColor Cyan
Write-Host 'If the settings are not 0 / OFF, a separate Reset V2 Lua handler may later reset again!' -ForegroundColor Yellow
Write-Host 'DANGER!! : if you do Reset Your Progression will Deleted. (This Cannot be Undone!) Not Happen to score records and game/mod files' -ForegroundColor Red
$confirmation = Read-Host 'Only if ID=0 and CONFIRM=OFF: type RESET if you really want sure'
if ($confirmation -cne 'RESET') {
    Write-Host 'Delete Cancelled'
    exit 0
}

try {
    # Delete exactly one previously identified, explicit progression save file.
    # No backup folder, backup save, or other output file is created.
    if ($target.Name -cne 'funktape_progression_v1.sol') {
        throw 'Cannot Do That! Unexpected filename'
    }
    if (!(Test-Path -LiteralPath $target.FullName -PathType Leaf)) {
        throw 'The target is no longer present'
    }
    Remove-Item -LiteralPath $target.FullName -Force -ErrorAction Stop
    if (Test-Path -LiteralPath $target.FullName) {
        throw 'Post-delete verification failed...'
    }
    Write-Host 'Reset Sucessful!' -ForegroundColor Green
    Write-Host 'i hope you do not change mind...'
} catch {
    Write-Host ('ERROR: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Check the save path before retrying.'
    exit 5
}
