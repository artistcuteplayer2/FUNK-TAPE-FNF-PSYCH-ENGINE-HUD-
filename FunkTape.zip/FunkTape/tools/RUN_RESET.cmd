@echo off
title FUNK-TAPE Progression Reset
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Reset_FunkTape_Progression.ps1"
echo.
pause
